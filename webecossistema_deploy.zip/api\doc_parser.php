<?php
/**
 * Helper de Documentação para Parsear Itens e Monstros dos arquivos .md do Servidor
 * Extrai as informações de drops, chances, HP, level e dano de forma estruturada.
 */

class DocParser {
    public static function getMonstersTier1() {
        $filePath = TFS_PATH . '/docs/monsters tiers/monstros_tier1.md';
        if (!file_exists($filePath)) {
            return [];
        }

        $content = file_get_contents($filePath);
        $lines = explode("\n", $content);
        $monsters = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line) || strpos($line, '|') === false || strpos($line, 'Monstro') !== false || strpos($line, '---') !== false) {
                continue;
            }

            // Exemplo: | **Rat** | 150 ao 500 | 150 | 150 | **9** | 0.5% | 0.3% | 0.2% | gold coin (max 8): 30.0%, ...
            $parts = explode('|', $line);
            if (count($parts) < 10) continue;

            $name = trim(str_replace('**', '', $parts[1]));
            $lvlRange = trim($parts[2]);
            $hp = (int)str_replace('.', '', trim($parts[3]));
            $xp = (int)str_replace('.', '', trim($parts[4]));
            $maxDano = trim(str_replace('**', '', $parts[5]));
            $mageHp = trim($parts[6]);
            $pallyHp = trim($parts[7]);
            $knightHp = trim($parts[8]);
            
            // Parseando loot list
            $lootRaw = trim($parts[9]);
            $lootPool = [];
            if (!empty($lootRaw)) {
                $loots = explode(',', $lootRaw);
                foreach ($loots as $l) {
                    $l = trim($l);
                    if (preg_match('/(.+?)\s*\((.+?)\):\s*(.+?)%/', $l, $m)) {
                        $lootPool[] = [
                            'name' => trim($m[1]),
                            'max' => trim($m[2]),
                            'chance' => trim($m[3])
                        ];
                    } elseif (preg_match('/(.+?):\s*(.+?)%/', $l, $m)) {
                        $lootPool[] = [
                            'name' => trim($m[1]),
                            'max' => 'max 1',
                            'chance' => trim($m[2])
                        ];
                    }
                }
            }

            $monsters[strtolower($name)] = [
                'name' => $name,
                'level_range' => $lvlRange,
                'hp' => $hp,
                'xp' => $xp,
                'max_dano' => $maxDano,
                'mage_hp' => $mageHp,
                'pally_hp' => $pallyHp,
                'knight_hp' => $knightHp,
                'loot' => $lootPool
            ];
        }

        return $monsters;
    }

    public static function getItemsTier1() {
        $filePath = TFS_PATH . '/docs/itens tiers/item_tier1.md';
        if (!file_exists($filePath)) {
            return [];
        }

        $content = file_get_contents($filePath);
        $lines = explode("\n", $content);
        $items = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line) || strpos($line, '|') === false || strpos($line, 'Item') !== false || strpos($line, '---') !== false) {
                continue;
            }

            // Exemplo: | **Spellbook** | 2175 | 648 | Def: 15 | Priestess (0.6%), ...
            $parts = explode('|', $line);
            if (count($parts) < 6) continue;

            $name = trim(str_replace('**', '', $parts[1]));
            $id860 = (int)trim($parts[2]);
            $id10 = (int)trim($parts[3]);
            $attrs = trim($parts[4]);
            $dropsRaw = trim($parts[5]);

            $dropPool = [];
            if (!empty($dropsRaw) && $dropsRaw !== 'None') {
                $drops = explode(',', $dropsRaw);
                foreach ($drops as $d) {
                    $d = trim($d);
                    if (preg_match('/(.+?)\s*\((.+?)%\)/', $d, $m)) {
                        $dropPool[] = [
                            'monster' => trim($m[1]),
                            'chance' => trim($m[2])
                        ];
                    }
                }
            }

            $items[strtolower($name)] = [
                'name' => $name,
                'id_860' => $id860,
                'id_10' => $id10,
                'attributes' => $attrs,
                'drops' => $dropPool
            ];
        }

        return $items;
    }
}
