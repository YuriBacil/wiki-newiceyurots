<?php
/**
 * API Administrativa - IceYuriots OT (VERSÃO DESACOPLADA)
 * Fornece dados do servidor apenas para GODs. As métricas são lidas
 * exclusivamente do banco do site (web), alimentado por api/sync.php.
 * O console.log do TFS continua sendo lido do arquivo (diagnóstico ao vivo
 * restrito ao admin) — não faz parte dos dados funcionais do site.
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/env.php';

session_start();

function getWebGroup() {
    return isset($_SESSION['web_group']) ? (int)$_SESSION['web_group'] : 1;
}

// Bloqueio Absoluto de Segurança: Apenas GODs (web_group >= 3)
if (getWebGroup() < 3) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado. Apenas administradores do sistema têm permissão de acesso.']);
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'metrics':
        try {
            $online = $pdoWeb->query("SELECT COUNT(*) AS online FROM web_players WHERE online = 1")->fetch();
            $playersOnline = (int)$online['online'];

            $acc = $pdoWeb->query("SELECT COUNT(*) AS total FROM web_accounts")->fetch();
            $totalAccounts = (int)$acc['total'];

            $pl = $pdoWeb->query("SELECT COUNT(*) AS total FROM web_players")->fetch();
            $totalPlayers = (int)$pl['total'];

            $dbStartTime = microtime(true);
            $pdoWeb->query("SELECT 1");
            $dbLatencyMs = round((microtime(true) - $dbStartTime) * 1000, 2);

            $posts = $pdoWeb->query("SELECT COUNT(*) AS total FROM web_community_posts")->fetch();
            $postsCount = (int)$posts['total'];

            $tickets = $pdoWeb->query("SELECT COUNT(*) AS total FROM web_tickets WHERE status = 'Aberto'")->fetch();
            $pendingTickets = (int)$tickets['total'];

            echo json_encode([
                'success' => true,
                'metrics' => [
                    'players_online' => $playersOnline,
                    'total_accounts' => $totalAccounts,
                    'total_players' => $totalPlayers,
                    'db_latency_ms' => $dbLatencyMs,
                    'posts_count' => $postsCount,
                    'pending_tickets' => $pendingTickets
                ]
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao processar métricas do painel.']);
        }
        break;

    case 'console_log':
        $logPath = CONSOLE_LOG_PATH;
        if (!file_exists($logPath)) {
            $mockLogs = [
                "[Warning - Items::loadFromXml] Deprecated attribute key in items.xml",
                "[Info - Server] IceYurots TFS 1.5 Server Online on port 7171!",
                "[Error - LuaScript] data/talkactions/scripts/perks.lua:12: table index is nil",
                "[Info - Database] Keep-alive thread started.",
                "[Warning - Spells::loadFromXml] Spell name 'Exura Max Ico' level required matches rules."
            ];
            echo json_encode([
                'success' => true,
                'logs' => implode("\n", $mockLogs) . "\n[Nota: Rodando em modo de simulação. Arquivo console.log não localizado no caminho local]"
            ]);
            exit;
        }

        $linesToRead = 150;
        $file = new SplFileObject($logPath, 'r');
        $file->seek(PHP_INT_MAX);
        $totalLines = $file->key();

        $startLine = max(0, $totalLines - $linesToRead);
        $file->seek($startLine);

        $logContent = "";
        while (!$file->eof()) {
            $logContent .= $file->current();
            $file->next();
        }

        echo json_encode(['success' => true, 'logs' => $logContent]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Ação de administração inválida.']);
        break;
}