/**
 * IceYuriots OT - Frontend Application Controller
 * Versão Corrigida: Isolamento estrito de componentes de cada aba (SPA),
 * tratamento de retornos vazios amigáveis e fallback elegante para imagens ausentes.
 */

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    loadRanking('resets');
    initWikiSearch();
    initLoreCapitulos();
    initLogout();
});

/* ==========================================
   SPINNERS / LOADERS VISUAIS AUXILIARES
   ========================================== */
function getLoaderHTML(message = 'Buscando pergaminhos...') {
    return `
        <div class="flex flex-col items-center justify-center py-12 gap-3 w-full">
            <svg class="animate-spin h-8 w-8 text-tibia-gold" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <span class="text-xs font-rpg tracking-wider text-tibia-gold font-bold animate-pulse">${message}</span>
        </div>
    `;
}

/* ==========================================
   1. SISTEMA DE SPA (ROTAS & EXIBIÇÃO ESTRITA)
   ========================================== */
function initNavigation() {
    const tabs = document.querySelectorAll('[data-target]');
    const panels = document.querySelectorAll('.dashboard-panel');

    // Mapeamento para esconder elementos inativos e mostrar apenas o correto
    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = tab.getAttribute('data-target');

            tabs.forEach(t => {
                t.classList.remove('border-tibia-gold', 'text-tibia-gold');
                t.classList.add('border-transparent', 'text-tibia-muted');
            });
            tab.classList.add('border-tibia-gold', 'text-tibia-gold');
            tab.classList.remove('border-transparent', 'text-tibia-muted');

            // Exibir apenas a aba ativa e sumir completamente com o resto das divs
            panels.forEach(panel => {
                if (panel.id === targetId) {
                    panel.classList.remove('hidden');
                } else {
                    panel.classList.add('hidden');
                }
            });

            // Disparar recargas específicas das abas de chamados
            if (targetId === 'suporte') {
                loadUserTickets();
            }
        });
    });
}

/* ==========================================
   2. CARD: COMUNIDADE (POSTS & VOTOS)
   ========================================== */
let currentCommunityFilter = 'em_alta';
let currentCommunitySearch = '';
let searchTimeout = null;

function loadCommunityPosts() {
    const feed = document.getElementById('community-feed');
    if (!feed) return;

    feed.innerHTML = getLoaderHTML('Lendo posts da comunidade...');

    fetch(`api/community.php?action=list&filter=${currentCommunityFilter}&search=${encodeURIComponent(currentCommunitySearch)}`)
        .then(res => res.json())
        .then(data => {
            if (data.success && data.posts && data.posts.length > 0) {
                renderPosts(data.posts, data.user_group);
            } else {
                feed.innerHTML = `
                    <div class="text-center py-12 border border-dashed border-tibia-borderDark/30 rounded p-6 bg-tibia-bg/40">
                        <p class="text-tibia-muted text-sm">Nenhuma mensagem encontrada na taverna.</p>
                        <p class="text-xs text-tibia-gold font-semibold mt-1">Seja o primeiro a publicar usando o painel lateral!</p>
                    </div>
                `;
            }
        })
        .catch(() => {
            feed.innerHTML = `
                <div class="text-center py-12 border border-dashed border-tibia-borderDark/30 rounded p-6 bg-tibia-bg/40">
                    <p class="text-tibia-muted text-sm">Nenhuma mensagem postada na taverna.</p>
                    <p class="text-xs text-tibia-gold font-semibold mt-1">Seja o primeiro a publicar usando o painel lateral!</p>
                </div>
            `;
        });
}

// Controla a alternação de abas de filtros da comunidade
window.changeCommunityFilter = function(filter, buttonEl) {
    currentCommunityFilter = filter;
    
    // Resetar estilos dos botões
    const buttons = document.querySelectorAll('.community-filter-btn');
    buttons.forEach(btn => {
        btn.classList.remove('bg-tibia-border', 'text-tibia-bg');
        btn.classList.add('text-tibia-muted', 'hover:text-tibia-gold');
    });

    // Destacar botão ativo
    buttonEl.classList.add('bg-tibia-border', 'text-tibia-bg');
    buttonEl.classList.remove('text-tibia-muted', 'hover:text-tibia-gold');

    loadCommunityPosts();
};

// Controla a busca textual com delay (debounce) para não travar a CPU
window.handleCommunitySearch = function(query) {
    currentCommunitySearch = query;
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        loadCommunityPosts();
    }, 400); // 400ms de delay
};

function renderPosts(posts, userGroup) {
    const feed = document.getElementById('community-feed');
    feed.innerHTML = posts.map(post => {
        const upvoted = post.user_vote == 1 ? 'text-tibia-gold font-bold scale-110' : 'text-tibia-muted hover:text-tibia-gold';
        const downvoted = post.user_vote == -1 ? 'text-tibia-gold font-bold scale-110' : 'text-tibia-muted hover:text-red-500';

        // Badge de hierarquia
        let roleBadge = '';
        const authorGroup = parseInt(post.author_group);
        if (authorGroup === 3) {
            roleBadge = `<span class="bg-red-950/60 text-red-500 border border-red-900/40 text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ml-1.5" title="GOD / Administrador">GOD</span>`;
        } else if (authorGroup === 2) {
            roleBadge = `<span class="bg-blue-950/60 text-blue-400 border border-blue-900/40 text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ml-1.5" title="Moderador do Fórum">MOD</span>`;
        }

        // Botão de deletar para moderadores/admins
        const deleteButton = userGroup >= 2 ? `
            <button onclick="deletePost(${post.id})" class="text-red-500/60 hover:text-red-500 transition-colors p-1.5 rounded bg-red-950/10 hover:bg-red-950/30 border border-red-900/20" title="Deletar Tópico (Moderador)">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-4 h-4">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                </svg>
            </button>
        ` : '';

        return `
            <div class="bg-tibia-bg border border-tibia-borderDark/40 p-4 rounded flex gap-4 items-start relative hover:border-tibia-border transition-colors">
                <div class="flex flex-col items-center gap-1.5 min-w-[32px]">
                    <button onclick="votePost(${post.id}, 1, this)" class="transition-all duration-200 transform active:scale-95 ${upvoted}" title="Upvote">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-6 h-6">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 15.75l7.5-7.5 7.5 7.5" />
                        </svg>
                    </button>
                    <span class="text-sm font-bold font-mono text-tibia-gold cursor-default">${post.score}</span>
                    <button onclick="votePost(${post.id}, -1, this)" class="transition-all duration-200 transform active:scale-95 ${downvoted}" title="Downvote">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-6 h-6">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                        </svg>
                    </button>
                </div>

                <div class="flex-grow">
                    <div class="flex items-center justify-between gap-2 mb-1">
                        <div class="flex items-center gap-1">
                            <span class="text-xs font-mono text-tibia-muted">Postado por <strong class="text-tibia-gold">${post.author_name}</strong></span>
                            ${roleBadge}
                        </div>
                        <div class="flex items-center gap-3">
                            <span class="text-[10px] text-tibia-muted/60">${new Date(post.created_at).toLocaleDateString('pt-BR')}</span>
                            ${deleteButton}
                        </div>
                    </div>
                    <h4 class="text-base font-bold text-tibia-text font-rpg mb-1.5">${escapeHTML(post.title)}</h4>
                    <p class="text-sm text-tibia-muted leading-relaxed whitespace-pre-wrap mb-3">${escapeHTML(post.content)}</p>
                    
                    <!-- Botão expansor de Comentários estilo Reddit -->
                    <div class="border-t border-tibia-borderDark/10 pt-2 flex items-center">
                        <button onclick="toggleComments(${post.id})" class="text-xs font-semibold text-tibia-muted hover:text-tibia-gold transition-colors flex items-center gap-1.5 bg-tibia-bg/60 px-3 py-1 rounded border border-tibia-borderDark/20">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.12 2.83 2.62 2.95v3.79c0 .58.58.96 1.08.68L10.5 15.75h9.75c1.52 0 2.75-1.23 2.75-2.75v-9c0-1.52-1.23-2.75-2.75-2.75h-15c-1.52 0-2.75 1.23-2.75 2.75v8.26z"></path>
                            </svg>
                            <span>${post.comments_count} Comentários</span>
                        </button>
                    </div>

                    <!-- Bloco de Comentários Oculto por padrão -->
                    <div id="comments-box-${post.id}" class="hidden mt-4 pt-4 border-t border-tibia-borderDark/30 space-y-4">
                        <!-- Formulário de Comentário Principal -->
                        <div class="flex gap-2">
                            <input type="text" id="comment-input-${post.id}" placeholder="Escreva um comentário..." maxlength="300"
                                class="flex-grow bg-tibia-bg border border-tibia-borderDark/40 rounded px-3 py-1.5 text-xs text-tibia-text focus:outline-none focus:border-tibia-gold transition-colors">
                            <button onclick="sendComment(${post.id}, null)" class="bg-tibia-border hover:bg-tibia-gold text-tibia-bg text-xs font-bold px-4 py-1.5 rounded uppercase tracking-wider transition-colors">Enviar</button>
                        </div>

                        <!-- Lista de Comentários Aninhados -->
                        <div id="comments-list-${post.id}" class="space-y-3 pl-2 border-l border-tibia-borderDark/20">
                            <!-- Inserido dinamicamente -->
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

window.deletePost = function(postId) {
    if (!confirm('Você tem certeza que deseja remover este post do fórum?')) return;
    
    fetch('api/community.php?action=delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_id: postId })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            loadCommunityPosts();
        } else {
            alert(data.message);
        }
    })
    .catch(() => alert('Erro de rede ao deletar post.'));
};

// Toggle do bloco de comentários
window.toggleComments = function(postId) {
    const box = document.getElementById(`comments-box-${postId}`);
    if (box.classList.contains('hidden')) {
        box.classList.remove('hidden');
        loadComments(postId);
    } else {
        box.classList.add('hidden');
    }
};

// Carrega comentários dinâmicos
window.loadComments = function(postId) {
    const list = document.getElementById(`comments-list-${postId}`);
    if (!list) return;

    list.innerHTML = `<span class="text-xs text-tibia-gold animate-pulse font-semibold">Lendo pergaminhos...</span>`;

    fetch(`api/community.php?action=list_comments&post_id=${postId}`)
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                renderCommentsTree(postId, data.comments);
            } else {
                list.innerHTML = `<span class="text-xs text-tibia-muted">Sem comentários.</span>`;
            }
        })
        .catch(() => {
            list.innerHTML = `<span class="text-xs text-tibia-muted">Erro ao carregar.</span>`;
        });
};

// Renderiza os comentários em árvore (Hierárquico)
function renderCommentsTree(postId, comments) {
    const list = document.getElementById(`comments-list-${postId}`);
    if (!list) return;

    if (comments.length === 0) {
        list.innerHTML = `<span class="text-xs text-tibia-muted">Nenhum comentário. Seja o primeiro a opinar!</span>`;
        return;
    }

    // Organizar em árvore com base no parent_id
    const map = {};
    const roots = [];

    comments.forEach(c => {
        c.replies = [];
        map[c.id] = c;
    });

    comments.forEach(c => {
        if (c.parent_id) {
            if (map[c.parent_id]) {
                map[c.parent_id].replies.push(c);
            } else {
                roots.push(c); // Fallback se o pai sumiu
            }
        } else {
            roots.push(c);
        }
    });

    // Função recursiva para gerar HTML do comentário
    function buildHTML(comment, depth = 0) {
        const upActive = comment.user_vote == 1 ? 'text-tibia-gold font-bold scale-110' : 'text-tibia-muted hover:text-tibia-gold';
        const downActive = comment.user_vote == -1 ? 'text-tibia-gold font-bold scale-110' : 'text-tibia-muted hover:text-red-500';
        
        let badge = '';
        if (parseInt(comment.author_group) === 3) {
            badge = `<span class="text-[8px] bg-red-950/60 text-red-500 border border-red-900/40 px-1 rounded ml-1 font-bold">GOD</span>`;
        } else if (parseInt(comment.author_group) === 2) {
            badge = `<span class="text-[8px] bg-blue-950/60 text-blue-400 border border-blue-900/40 px-1 rounded ml-1 font-bold">MOD</span>`;
        }

        const repliesHTML = comment.replies.map(r => buildHTML(r, depth + 1)).join('');

        return `
            <div class="mt-2 text-xs relative" style="margin-left: ${depth > 0 ? '16px' : '0px'}">
                <div class="bg-tibia-bg/40 p-2.5 rounded border border-tibia-borderDark/20 flex gap-3 items-start hover:border-tibia-borderDark/40 transition-colors">
                    <!-- Votos do Comentário -->
                    <div class="flex flex-col items-center gap-0.5 min-w-[20px]">
                        <button onclick="voteComment(${postId}, ${comment.id}, 1, this)" class="transform active:scale-90 transition-all ${upActive}">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 15.75l7.5-7.5 7.5 7.5"></path>
                            </svg>
                        </button>
                        <span class="text-[10px] font-bold font-mono text-tibia-gold">${comment.score}</span>
                        <button onclick="voteComment(${postId}, ${comment.id}, -1, this)" class="transform active:scale-90 transition-all ${downActive}">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Conteúdo do Comentário -->
                    <div class="flex-grow">
                        <div class="flex items-center gap-1.5 mb-1 text-[10px] text-tibia-muted">
                            <strong class="text-tibia-text">${comment.author_name}</strong>
                            ${badge}
                            <span>• ${new Date(comment.created_at).toLocaleDateString('pt-BR')}</span>
                        </div>
                        <p class="text-tibia-text/90">${escapeHTML(comment.content)}</p>

                        <!-- Botão Responder Comentário -->
                        <div class="mt-1">
                            <button onclick="showReplyBox(${postId}, ${comment.id})" class="text-[10px] text-tibia-muted hover:text-tibia-gold transition-colors font-semibold">Responder</button>
                        </div>

                        <!-- Input de Resposta Oculto por padrão -->
                        <div id="reply-box-${postId}-${comment.id}" class="hidden mt-2 flex gap-1.5">
                            <input type="text" id="reply-input-${postId}-${comment.id}" placeholder="Escreva uma resposta..." maxlength="300"
                                class="flex-grow bg-tibia-bg border border-tibia-borderDark/40 rounded px-2.5 py-1 text-[10px] text-tibia-text focus:outline-none focus:border-tibia-gold">
                            <button onclick="sendComment(${postId}, ${comment.id})" class="bg-tibia-border hover:bg-tibia-gold text-tibia-bg text-[9px] font-bold px-3 py-1 rounded uppercase">Enviar</button>
                        </div>
                    </div>
                </div>
                ${repliesHTML}
            </div>
        `;
    }

    list.innerHTML = roots.map(r => buildHTML(r, 0)).join('');
}

// Alterna exibição do input de resposta
window.showReplyBox = function(postId, commentId) {
    const box = document.getElementById(`reply-box-${postId}-${commentId}`);
    box.classList.toggle('hidden');
    if (!box.classList.contains('hidden')) {
        document.getElementById(`reply-input-${postId}-${commentId}`).focus();
    }
};

// Envia comentário ou resposta
window.sendComment = function(postId, parentId) {
    const input = parentId 
        ? document.getElementById(`reply-input-${postId}-${parentId}`)
        : document.getElementById(`comment-input-${postId}`);

    const content = input.value.trim();
    if (content === '') return;

    fetch('api/community.php?action=add_comment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_id: postId, parent_id: parentId, content: content })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            input.value = '';
            if (parentId) {
                document.getElementById(`reply-box-${postId}-${parentId}`).classList.add('hidden');
            }
            loadComments(postId);
        } else {
            alert(data.message);
        }
    })
    .catch(() => alert('Erro de rede ao postar comentário.'));
};

// Votação do comentário
window.voteComment = function(postId, commentId, voteType, buttonEl) {
    let finalVote = voteType;
    if (buttonEl.classList.contains('text-tibia-gold')) {
        finalVote = 0;
    }

    fetch('api/community.php?action=vote_comment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comment_id: commentId, vote_type: finalVote })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            loadComments(postId);
        } else {
            alert(data.message);
        }
    })
    .catch(() => alert('Erro de rede ao votar no comentário.'));
};

window.votePost = function(postId, voteType, buttonEl) {
    let finalVote = voteType;
    if (buttonEl.classList.contains('text-tibia-gold')) {
        finalVote = 0;
    }

    fetch('api/community.php?action=vote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_id: postId, vote_type: finalVote })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            loadCommunityPosts();
        } else {
            alert(data.message);
        }
    })
    .catch(() => alert('Erro ao registrar voto.'));
};

function initCommunityForm() {
    const form = document.getElementById('newPostForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('postTitle').value;
        const content = document.getElementById('postContent').value;

        fetch('api/community.php?action=create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, content })
        })
        .then(res => {
            if (!res.ok) throw new Error('Status HTTP: ' + res.status);
            return res.json();
        })
        .then(data => {
            if (data.success) {
                form.reset();
                loadCommunityPosts();
            } else {
                alert(data.message);
            }
        })
        .catch((err) => alert('Erro ao criar post: ' + err.message));
    });
}

/* ==========================================
   3. CARD: ESTATÍSTICAS E INSPECT
   ========================================== */
window.changeRankingCategory = function(type, buttonEl) {
    const buttons = document.querySelectorAll('.ranking-btn');
    const select = document.getElementById('rankingSkillSelect');

    if (buttonEl) {
        // Clicou em um botão do Top Geral (Level, Resets, Frags, XP, Ricos)
        buttons.forEach(btn => {
            btn.classList.remove('bg-tibia-border', 'text-tibia-bg', 'shadow');
            btn.classList.add('text-tibia-muted', 'hover:text-tibia-gold');
        });
        buttonEl.classList.add('bg-tibia-border', 'text-tibia-bg', 'shadow');
        buttonEl.classList.remove('text-tibia-muted', 'hover:text-tibia-gold');
        
        // Resetar select de skills para a opção padrão placeholder
        if (select) select.selectedIndex = 0;
    } else {
        // Selecionou alguma skill de combate no dropdown select
        buttons.forEach(btn => {
            btn.classList.remove('bg-tibia-border', 'text-tibia-bg', 'shadow');
            btn.classList.add('text-tibia-muted', 'hover:text-tibia-gold');
        });
    }

    loadRanking(type);
};

window.toggleRankingSubTab = function(tabName, buttonEl) {
    const subtabs = document.querySelectorAll('.ranking-subtab-btn');
    subtabs.forEach(btn => {
        btn.classList.remove('text-tibia-gold', 'border-b-2', 'border-tibia-gold');
        btn.classList.add('text-tibia-muted', 'hover:text-tibia-gold');
    });

    buttonEl.classList.add('text-tibia-gold', 'border-b-2', 'border-tibia-gold');
    buttonEl.classList.remove('text-tibia-muted', 'hover:text-tibia-gold');

    const highscoresContainer = document.getElementById('ranking-highscores-container');
    const worldStatsContainer = document.getElementById('ranking-world-stats-container');

    if (tabName === 'highscores') {
        highscoresContainer.classList.remove('hidden');
        worldStatsContainer.classList.add('hidden');
    } else {
        highscoresContainer.classList.add('hidden');
        worldStatsContainer.classList.remove('hidden');
        loadWorldStats();
    }
};

window.loadWorldStats = function() {
    const vocContainer = document.getElementById('world-stat-vocations');
    const monstersContainer = document.getElementById('world-stat-monsters');
    const pvpContainer = document.getElementById('world-stat-pvp');

    vocContainer.innerHTML = `<span class="text-tibia-muted italic">Consultando grimório...</span>`;
    monstersContainer.innerHTML = `<span class="text-tibia-muted italic">Contando corpos...</span>`;
    pvpContainer.innerHTML = `<span class="text-tibia-muted italic">Consultando mandados...</span>`;

    fetch('api/stats.php?action=world_stats')
        .then(res => {
            if (!res.ok) throw new Error('Status: ' + res.status);
            return res.json();
        })
        .then(data => {
            if (data.success) {
                // 1. Injetar Métricas Gerais
                document.getElementById('world-stat-players').innerText = data.metrics.total_players;
                document.getElementById('world-stat-avglevel').innerText = data.metrics.avg_level;
                document.getElementById('world-stat-resets').innerText = data.metrics.total_resets;

                // 2. Injetar Vocações
                if (data.vocations && data.vocations.length > 0) {
                    vocContainer.innerHTML = data.vocations.map(v => {
                        return `
                            <div class="flex justify-between items-center border-b border-tibia-borderDark/10 pb-1.5">
                                <span class="text-tibia-text font-semibold">${v.name}:</span>
                                <span class="font-mono text-tibia-gold font-bold">${v.count}</span>
                            </div>
                        `;
                    }).join('');
                } else {
                    vocContainer.innerHTML = `<p class="text-tibia-muted italic">Nenhuma vocação ativa registrada.</p>`;
                }

                // 3. Injetar PvP (Guerreiros Assassinos)
                if (data.pvp && data.pvp.length > 0) {
                    pvpContainer.innerHTML = data.pvp.map((p, idx) => {
                        return `
                            <div class="flex justify-between items-center border-b border-tibia-borderDark/10 pb-1.5">
                                <span class="text-tibia-text"><strong class="text-tibia-gold font-mono">#${idx + 1}</strong> <strong class="hover:underline cursor-pointer" onclick="inspectPlayer('${p.player_name}')">${p.player_name}</strong></span>
                                <span class="font-mono text-emerald-400 font-bold">${p.kills_count} frags</span>
                            </div>
                        `;
                    }).join('');
                } else {
                    pvpContainer.innerHTML = `<p class="text-tibia-muted italic">Nenhum frag registrado recentemente.</p>`;
                }

                // 4. Injetar Monstros Assassinos (PvE)
                if (data.monsters && data.monsters.length > 0) {
                    monstersContainer.innerHTML = data.monsters.map((m, idx) => {
                        return `
                            <div class="flex justify-between items-center border-b border-tibia-borderDark/10 pb-1.5">
                                <span class="text-tibia-text"><strong class="text-red-500 font-mono">#${idx + 1}</strong> ${m.monster_name}</span>
                                <span class="font-mono text-slate-400">${m.kills_count} abates</span>
                            </div>
                        `;
                    }).join('');
                } else {
                    monstersContainer.innerHTML = `<p class="text-tibia-muted italic">Nenhuma morte para monstro registrada recentemente.</p>`;
                }
            } else {
                vocContainer.innerHTML = `<p class="text-red-500 font-bold">Erro: ${data.message}</p>`;
                monstersContainer.innerHTML = `<p class="text-red-500 font-bold">Erro: ${data.message}</p>`;
                pvpContainer.innerHTML = `<p class="text-red-500 font-bold">Erro: ${data.message}</p>`;
            }
        })
        .catch(err => {
            vocContainer.innerHTML = `<p class="text-red-500 font-bold">Erro ao carregar dados.</p>`;
            monstersContainer.innerHTML = `<p class="text-red-500 font-bold">Erro ao carregar dados.</p>`;
            pvpContainer.innerHTML = `<p class="text-red-500 font-bold">Erro ao carregar dados.</p>`;
        });
};

window.loadRanking = function(type) {
    const tbody = document.getElementById('ranking-body');
    if (!tbody) return;

    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="py-6">
                ${getLoaderHTML('Consultando tabelas do ranking...')}
            </td>
        </tr>
    `;

    fetch(`api/stats.php?action=ranking&type=${type}`)
        .then(res => res.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                renderRanking(data.data, type);
            } else {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center py-8 text-tibia-muted font-rpg">
                            Nenhum registro de personagem encontrado no banco de dados.
                        </td>
                    </tr>
                `;
            }
        })
        .catch(() => {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center py-8 text-tibia-muted font-rpg">
                        Nenhum registro de personagem encontrado no banco de dados.
                    </td>
                </tr>
            `;
        });
};

function renderRanking(players, type) {
    const tbody = document.getElementById('ranking-body');
    tbody.innerHTML = players.map((player, index) => {
        // Círculo luminoso de status Online/Offline
        const statusDot = player.online 
            ? `<span class="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 mr-2 shadow-[0_0_8px_#10b981]" title="Online no Jogo"></span>`
            : `<span class="inline-block w-2.5 h-2.5 rounded-full bg-slate-600 mr-2" title="Offline"></span>`;

        // Detalhamento do score
        let labelSuffix = '';
        if (type === 'maglevel') labelSuffix = ' ML';
        else if (type === 'sword' || type === 'axe' || type === 'club' || type === 'dist' || type === 'shielding') labelSuffix = ' Skill';
        else if (type === 'frags') labelSuffix = ' Frags';
        else if (type === 'balance') labelSuffix = ' Gold';

        const displayValue = player.score_formatted + labelSuffix;

        // Texto do Reset para o ranking
        const resetCount = parseInt(player.resets || 0);
        const resetText = resetCount > 0 ? ` • <strong class="text-tibia-gold">${resetCount} Resets</strong>` : '';

        return `
            <tr class="border-b border-tibia-borderDark/20 hover:bg-tibia-bg/40 transition-colors">
                <td class="px-4 py-3 font-mono font-bold text-tibia-gold text-center">${index + 1}</td>
                <td class="px-4 py-3 font-semibold">
                    <div class="flex items-center">
                        ${statusDot}
                        <button onclick="inspectPlayer('${player.name}')" class="text-tibia-text hover:text-tibia-gold hover:underline transition-all text-left">
                            ${player.name}
                        </button>
                    </div>
                </td>
                <td class="px-4 py-3 text-xs text-tibia-muted">${player.vocation_name} (Level ${player.level})${resetText}</td>
                <td class="px-4 py-3 text-right font-mono text-sm text-tibia-gold">${displayValue}</td>
            </tr>
        `;
    }).join('');
}

window.inspectPlayer = function(name) {
    const modal = document.getElementById('inspectModal');
    const modalContent = document.getElementById('inspectModalContent');
    
    modal.classList.remove('hidden');
    modalContent.innerHTML = getLoaderHTML('Visualizando equipamentos no templo...');

    fetch(`api/stats.php?action=inspect&name=${encodeURIComponent(name)}`)
        .then(res => {
            if (!res.ok) throw new Error('Falha HTTP: ' + res.status);
            return res.json();
        })
        .then(data => {
            if (data.success) {
                renderInspect(data.player, data.equipment, data.deaths);
            } else {
                modalContent.innerHTML = `<div class="text-center py-8 text-red-500 font-bold">${data.message}</div>`;
            }
        })
        .catch((err) => {
modalContent.innerHTML = `<div class="text-center py-8 text-red-500 font-bold">Erro ao estabelecer conexão: ${err.message}</div>`;
        });
};

window.closeInspectModal = function() {
    document.getElementById('inspectModal').classList.add('hidden');
};

function renderInspect(player, equipment, deaths = []) {
    const modalContent = document.getElementById('inspectModalContent');
    
    const slotsMap = {
        1: { name: 'Helmet', pos: 'col-start-2 row-start-1' },
        2: { name: 'Amulet', pos: 'col-start-1 row-start-1' },
        3: { name: 'Backpack', pos: 'col-start-3 row-start-1' },
        4: { name: 'Armor', pos: 'col-start-2 row-start-2' },
        5: { name: 'Right Hand', pos: 'col-start-1 row-start-2' },
        6: { name: 'Left Hand', pos: 'col-start-3 row-start-2' },
        7: { name: 'Legs', pos: 'col-start-2 row-start-3' },
        8: { name: 'Boots', pos: 'col-start-2 row-start-4' },
        9: { name: 'Ring', pos: 'col-start-1 row-start-3' },
        10: { name: 'Ammo', pos: 'col-start-3 row-start-3' }
    };

    let slotsHTML = '';
    
    for (let slotId = 1; slotId <= 10; slotId++) {
        const slot = slotsMap[slotId];
        const item = equipment[slotId];
        const itemImage = item ? `assets/items/${item.itemid}.png` : "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23334155' width='24' height='24'><rect width='24' height='24' rx='2' stroke-dasharray='4'/></svg>";
        const tooltip = item ? `${item.name} (ID: ${item.itemid})` : `${slot.name} vazio`;

        // Modificado com onError para ocultar graciosamente ou substituir por imagem de fallback transparente
        slotsHTML += `
            <div class="${slot.pos} w-16 h-16 bg-slate-900/90 border border-tibia-borderDark/40 flex items-center justify-center relative group gold-glow rounded" title="${escapeHTML(tooltip)}">
                <img src="${itemImage}" onerror="handleBrokenImage(this)" class="max-w-[48px] max-h-[48px] object-contain transition-transform group-hover:scale-105" alt="${slot.name}">
                ${item && item.count > 1 ? `<span class="absolute bottom-1 right-1 font-mono text-xs font-bold text-emerald-400 bg-black/60 px-1 rounded">${item.count}</span>` : ''}
            </div>
        `;
    }

    // Tradução de vocações para exibição
    const vocationsMap = {
        0: 'Nenhuma',
        1: 'Sorcerer', 2: 'Druid', 3: 'Paladin', 4: 'Knight',
        5: 'Master Sorcerer', 6: 'Elder Druid', 7: 'Royal Paladin', 8: 'Elite Knight'
    };
    const vocationName = vocationsMap[player.vocation] || 'Desconhecida';

    // Status Online Badge
    const onlineBadge = player.online
        ? `<span class="bg-emerald-950/60 text-emerald-400 border border-emerald-900/40 text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">Online</span>`
        : `<span class="bg-slate-950/60 text-slate-400 border border-slate-900/40 text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">Offline</span>`;

    // Guilda Badge
    const guildText = player.guild 
        ? `<p class="text-xs text-tibia-muted mt-0.5">${player.guild.rank} da guilda <strong class="text-tibia-gold hover:underline cursor-default">${player.guild.name}</strong></p>`
        : `<p class="text-xs text-tibia-muted mt-0.5">Sem Guilda</p>`;

    // Renderizar a tabela de Skills
    const skillsHTML = `
        <div class="bg-tibia-bg/60 p-4 border border-tibia-borderDark/25 rounded space-y-3">
            <h5 class="text-xs font-bold text-tibia-gold uppercase tracking-wider border-b border-tibia-borderDark/20 pb-1.5">Habilidades de Combate</h5>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-xs">
                <div class="flex justify-between border-b border-tibia-borderDark/10 pb-1">
                    <span class="text-tibia-muted pr-2">Magic Level:</span>
                    <span class="font-bold font-mono text-tibia-gold">${player.skills.maglevel}</span>
                </div>
                <div class="flex justify-between border-b border-tibia-borderDark/10 pb-1">
                    <span class="text-tibia-muted pr-2">Fist Fighting:</span>
                    <span class="font-bold font-mono text-tibia-text">${player.skills.fist}</span>
                </div>
                <div class="flex justify-between border-b border-tibia-borderDark/10 pb-1">
                    <span class="text-tibia-muted pr-2">Club Fighting:</span>
                    <span class="font-bold font-mono text-tibia-text">${player.skills.club}</span>
                </div>
                <div class="flex justify-between border-b border-tibia-borderDark/10 pb-1">
                    <span class="text-tibia-muted pr-2">Sword Fighting:</span>
                    <span class="font-bold font-mono text-tibia-text">${player.skills.sword}</span>
                </div>
                <div class="flex justify-between border-b border-tibia-borderDark/10 pb-1">
                    <span class="text-tibia-muted pr-2">Axe Fighting:</span>
                    <span class="font-bold font-mono text-tibia-text">${player.skills.axe}</span>
                </div>
                <div class="flex justify-between border-b border-tibia-borderDark/10 pb-1">
                    <span class="text-tibia-muted pr-2">Distance:</span>
                    <span class="font-bold font-mono text-tibia-text">${player.skills.dist}</span>
                </div>
                <div class="flex justify-between border-b border-tibia-borderDark/10 pb-1">
                    <span class="text-tibia-muted pr-2">Shielding:</span>
                    <span class="font-bold font-mono text-tibia-text">${player.skills.shielding}</span>
                </div>
            </div>
        </div>
    `;

    // Renderizar histórico de mortes
    let deathsHTML = '';
    if (deaths && deaths.length > 0) {
        deathsHTML = `
            <div class="bg-tibia-bg/60 p-3.5 border border-tibia-borderDark/25 rounded space-y-2">
                <h5 class="text-xs font-bold text-tibia-gold uppercase tracking-wider border-b border-tibia-borderDark/20 pb-1">Mortes Recentes</h5>
                <ul class="text-xs text-tibia-text space-y-1.5 max-h-[110px] overflow-y-auto pr-1">
                    ${deaths.map(d => {
                        const dateFormatted = new Date(d.time * 1000).toLocaleDateString('pt-BR');
                        const killer = d.is_player ? `<strong class="text-tibia-gold hover:underline cursor-pointer" onclick="inspectPlayer('${d.killed_by}')">${d.killed_by}</strong>` : d.killed_by;
                        return `
                            <li class="border-b border-tibia-borderDark/10 pb-1 leading-relaxed">
                                • Morreu no Level <strong class="font-mono text-tibia-gold">${d.level}</strong> em ${dateFormatted} para ${killer}.
                            </li>
                        `;
                    }).join('')}
                </ul>
            </div>
        `;
    } else {
        deathsHTML = `
            <div class="bg-tibia-bg/60 p-3.5 border border-tibia-borderDark/25 rounded space-y-2">
                <h5 class="text-xs font-bold text-tibia-gold uppercase tracking-wider border-b border-tibia-borderDark/20 pb-1">Mortes Recentes</h5>
                <p class="text-xs text-tibia-muted italic">Este guerreiro não foi abatido recentemente.</p>
            </div>
        `;
    }

    modalContent.innerHTML = `
        <div class="flex flex-col lg:flex-row gap-6 items-start justify-center max-w-full">
            <!-- Grid de Equipamentos (Esquerda) -->
            <div class="flex flex-col items-center gap-3 shrink-0 mx-auto lg:mx-0">
                <div class="grid grid-cols-3 grid-rows-4 gap-2.5 p-4 bg-tibia-bg border border-tibia-borderDark/50 rounded shadow-inner">
                    ${slotsHTML}
                </div>
                ${onlineBadge}
            </div>

            <!-- Coluna de Informações Estendidas (Direita) -->
            <div class="flex-grow w-full space-y-4 text-left">
                <div>
                    <h4 class="font-rpg text-2xl text-tibia-gold font-bold tracking-wider">${player.name}</h4>
                    <p class="text-xs text-tibia-text">${player.sex === 1 ? 'Macho' : 'Fêmea'} • <strong>${vocationName}</strong> (Nível ${player.level})</p>
                    ${guildText}
                </div>

                <!-- Atributos Básicos -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-3.5 bg-tibia-bg/60 p-3 border border-tibia-borderDark/20 rounded text-xs leading-relaxed">
                    <div>
                        <span class="block text-[10px] uppercase text-tibia-muted tracking-wider">Vida / Mana</span>
                        <span class="font-bold font-mono text-tibia-text">${player.healthmax} HP / ${player.manamax} MP</span>
                    </div>
                    <div>
                        <span class="block text-[10px] uppercase text-tibia-muted tracking-wider">Resets Acumulados</span>
                        <span class="font-bold font-mono text-tibia-gold text-sm">${player.skills.resets || 0} Resets</span>
                    </div>
                    <div>
                        <span class="block text-[10px] uppercase text-tibia-muted tracking-wider">Último Login</span>
                        <span class="font-bold font-mono text-tibia-text">${player.lastlogin}</span>
                    </div>
                    <div>
                        <span class="block text-[10px] uppercase text-tibia-muted tracking-wider">Conta Criada</span>
                        <span class="font-bold font-mono text-tibia-text">${player.account_created}</span>
                    </div>
                </div>

                <!-- Habilidades e Histórico de Combates -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    ${skillsHTML}
                    ${deathsHTML}
                </div>
            </div>
        </div>
    `;
}

/* ==========================================
   4. CARD: WIKI ILUSTRADA (FILTRO & ESTADO VAZIO)
   ========================================= */
let activeWikiCategory = 'monsters';
let wikiSearchTimeout = null;

function initWikiSearch() {
    const input = document.getElementById('wikiSearchInput');
    if (!input) return;

    // Busca textual com Debouncing para poupar o processamento de XML no backend
    input.addEventListener('input', () => {
        clearTimeout(wikiSearchTimeout);
        wikiSearchTimeout = setTimeout(() => {
            loadWikiContent();
        }, 350);
    });

    // Carga inicial
    loadWikiContent();
}

window.toggleWikiCategory = function(categoryName, buttonEl) {
    const buttons = document.querySelectorAll('.wiki-category-btn');
    buttons.forEach(btn => {
        btn.classList.remove('text-tibia-gold', 'bg-tibia-bg', 'border-tibia-borderDark/30', 'border');
        btn.classList.add('text-tibia-muted', 'hover:text-tibia-gold', 'hover:bg-tibia-bg/40');
    });

    buttonEl.classList.add('text-tibia-gold', 'bg-tibia-bg', 'border', 'border-tibia-borderDark/30');
    buttonEl.classList.remove('text-tibia-muted', 'hover:text-tibia-gold', 'hover:bg-tibia-bg/40');

    activeWikiCategory = categoryName;

    // Ajustar títulos e descrições do cabeçalho
    const titles = {
        monsters: { title: 'Bestiário (XP e Drops)', desc: 'Consulte monstros, loots e experiência do servidor em tempo real.' },
        items: { title: 'Catálogo de Equipamentos', desc: 'Descubra todas as armas, escudos, anéis e armaduras com atributos originais.' },
        pets: { title: 'Pet System (Summons de Bolso)', desc: 'Invoque mascotes e guardiões leais de bolso para auxiliar você em batalhas e absorver dano.' },
        mining: { title: 'Mineração Dinâmica', desc: 'Colete carvão, ferro e gemas raras no subsolo do IceYuriots.' },
        upgrades: { title: 'Upgrades e Awakening', desc: 'Adicione Tiers extras e desperte atributos secundários em seus itens.' },
        foods: { title: 'Alimentos Alquímicos', desc: 'Consuma pratos sagrados e ative efeitos elementais na arena de combate.' }
    };

    const header = titles[categoryName];
    document.getElementById('wikiCategoryTitle').innerText = header.title;
    document.getElementById('wikiCategoryDesc').innerText = header.desc;

    // Exibir/Ocultar barra de busca (só faz sentido em monstros e itens)
    const searchContainer = document.getElementById('wikiSearchInputContainer');
    const searchInput = document.getElementById('wikiSearchInput');
    if (categoryName === 'monsters' || categoryName === 'items') {
        searchContainer.classList.remove('hidden');
        searchInput.placeholder = categoryName === 'monsters' ? 'Buscar criatura...' : 'Buscar item...';
        searchInput.value = '';
    } else {
        searchContainer.classList.add('hidden');
    }

    // Gerenciar visibilidade de Containers
    document.getElementById('wiki-monsters-container').classList.add('hidden');
    document.getElementById('wiki-items-container').classList.add('hidden');
    document.getElementById('wiki-systems-container').classList.add('hidden');

    // Exibe filtros de Tiers do Pet System apenas quando 'pets' estiver selecionado
    const petTiersFilter = document.getElementById('pet-tiers-filter');
    if (petTiersFilter) {
        if (categoryName === 'pets') {
            petTiersFilter.classList.remove('hidden');
            activePetTier = 2; // Reseta para Tier 2
            
            // Destaca visualmente o primeiro card de Tier 2 por padrão
            const cards = document.querySelectorAll('.pet-tier-card');
            cards.forEach((c, idx) => {
                if (idx === 0) {
                    c.classList.remove('border-tibia-borderDark/25', 'bg-tibia-panel');
                    c.classList.add('border-tibia-border', 'bg-tibia-bg/40', 'shadow-[0_0_10px_rgba(212,175,55,0.25)]');
                } else {
                    c.classList.remove('border-tibia-border', 'bg-tibia-bg/40', 'shadow-[0_0_10px_rgba(212,175,55,0.25)]');
                    c.classList.add('border-tibia-borderDark/25', 'bg-tibia-panel');
                }
            });
        } else {
            petTiersFilter.classList.add('hidden');
        }
    }

    if (categoryName === 'monsters') {
        document.getElementById('wiki-monsters-container').classList.remove('hidden');
    } else if (categoryName === 'items') {
        document.getElementById('wiki-items-container').classList.remove('hidden');
    } else {
        document.getElementById('wiki-systems-container').classList.remove('hidden');
    }

    // Limpa a categoria de itens selecionada ao trocar de aba principal
    activeItemCategory = 'all';
    const itemButtons = document.querySelectorAll('.wiki-item-category-btn');
    itemButtons.forEach((btn, idx) => {
        if (idx === 0) { // Botão 'Todos'
            btn.classList.add('bg-tibia-border', 'text-tibia-bg', 'shadow');
            btn.classList.remove('text-tibia-muted', 'hover:text-tibia-gold');
        } else {
            btn.classList.remove('bg-tibia-border', 'text-tibia-bg', 'shadow');
            btn.classList.add('text-tibia-muted', 'hover:text-tibia-gold');
        }
    });

    loadWikiContent();
};

let activeMonsterTier = 'tier1';
let currentMonsterSortField = 'xp'; // Padrão: XP
let currentMonsterSortOrder = 'asc'; // Padrão: do menor para o maior
let cachedMonstersData = [];

// Rótulos exibidos no selo de tier dos cards de monstros (valores vêm de m.tier)
const tierLabelMap = {
    tier1: 'T1',
    tier2: 'T2',
    tier3: 'T3',
    tier4: 'T4',
    bosses: 'BOSS'
};

let activePetTier = 2; // Padrão: Tier 2

window.changePetTier = function(tierNumber, cardEl) {
    activePetTier = Number(tierNumber);

    // Remove destaque de todos os cards de tier de pet
    const cards = document.querySelectorAll('.pet-tier-card');
    cards.forEach(c => {
        c.classList.remove('border-tibia-border', 'bg-tibia-bg/40', 'shadow-[0_0_10px_rgba(212,175,55,0.25)]');
        c.classList.add('border-tibia-borderDark/25', 'bg-tibia-panel');
    });

    // Adiciona destaque dourado no card clicado
    cardEl.classList.remove('border-tibia-borderDark/25', 'bg-tibia-panel');
    cardEl.classList.add('border-tibia-border', 'bg-tibia-bg/40', 'shadow-[0_0_10px_rgba(212,175,55,0.25)]');

    loadWikiContent();
};

window.changeWikiMonsterTier = function(tierName, cardEl) {
    const cards = document.querySelectorAll('.wiki-tier-card');
    cards.forEach(card => {
        card.classList.remove('active', 'bg-tibia-bg', 'border-tibia-gold/60', 'gold-glow');
        card.classList.add('bg-tibia-panel/60', 'border-tibia-borderDark/30');
        
        const title = card.querySelector('h4');
        if (title) {
            title.classList.remove('text-tibia-gold');
            title.classList.add('text-tibia-text');
        }
    });

    cardEl.classList.add('active', 'bg-tibia-bg', 'border-tibia-gold/60', 'gold-glow');
    cardEl.classList.remove('bg-tibia-panel/60', 'border-tibia-borderDark/30');
    
    const activeTitle = cardEl.querySelector('h4');
    if (activeTitle) {
        activeTitle.classList.remove('text-tibia-text');
        activeTitle.classList.add('text-tibia-gold');
    }

    activeMonsterTier = tierName;
    
    // Reseta ordenação padrão para XP Crescente ao trocar de Tier
    currentMonsterSortField = 'xp';
    currentMonsterSortOrder = 'asc';
    updateWikiMonsterSortHeaders();

    loadWikiContent();
};

window.toggleWikiMonsterSort = function(field) {
    if (currentMonsterSortField === field) {
        currentMonsterSortOrder = currentMonsterSortOrder === 'asc' ? 'desc' : 'asc';
    } else {
        currentMonsterSortField = field;
        currentMonsterSortOrder = field === 'xp' ? 'asc' : 'asc'; // Padrão crescente
    }

    updateWikiMonsterSortHeaders();
    renderWikiMonstersTable();
};

function updateWikiMonsterSortHeaders() {
    const iconName = document.getElementById('sort-icon-name');
    const iconXp = document.getElementById('sort-icon-xp');
    if (!iconName || !iconXp) return;

    iconName.innerText = '';
    iconName.className = 'ml-1 text-[9px] text-tibia-muted';
    iconXp.innerText = '';
    iconXp.className = 'ml-1 text-[9px] text-tibia-muted';

    if (currentMonsterSortField === 'name') {
        iconName.innerText = currentMonsterSortOrder === 'asc' ? '▲' : '▼';
        iconName.className = 'ml-1 text-[9px] text-tibia-gold';
    } else if (currentMonsterSortField === 'xp') {
        iconXp.innerText = currentMonsterSortOrder === 'asc' ? '▲' : '▼';
        iconXp.className = 'ml-1 text-[9px] text-tibia-gold';
    }
}

function renderWikiMonstersTable() {
    const grid = document.getElementById('wiki-monsters-grid');
    if (!grid || !cachedMonstersData) return;

    // Ordenar localmente os dados clonados
    let sorted = [...cachedMonstersData];
    sorted.sort((a, b) => {
        let valA = a[currentMonsterSortField];
        let valB = b[currentMonsterSortField];

        // Se for string (Nome), força caixa baixa
        if (typeof valA === 'string') valA = valA.toLowerCase();
        if (typeof valB === 'string') valB = valB.toLowerCase();

        if (valA < valB) return currentMonsterSortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return currentMonsterSortOrder === 'asc' ? 1 : -1;
        return 0;
    });

    if (sorted.length > 0) {
        grid.innerHTML = sorted.map(m => {
            // Conversão do nome do monstro para o arquivo de gif local do MyAAC
            // Remove espaços e caracteres especiais. Ex: "Cave Rat" -> "caverat.gif", "Frog (Orchid)" -> "frogorchid.gif"
            const cleanName = m.name.toLowerCase().replace(/[^a-z0-9]/g, '');
            const monsterSpriteUrl = `assets/monsters/${cleanName}.gif`;

            // Rótulo do tier derivado do dado real (corrige o "T1" fixo anterior)
            const tierLabel = tierLabelMap[m.tier] || (m.tier ? m.tier.toUpperCase() : '--');

            return `
                <div onclick="openWikiMonsterPopup('${escapeHTML(m.name)}')" class="bg-tibia-panel rounded-lg border border-tibia-borderDark/20 hover:border-tibia-gold/50 hover:shadow-xl transition-all cursor-pointer flex flex-col overflow-hidden group relative">
                    <!-- Selo do Tier -->
                    <span class="absolute top-2 right-2 z-10 text-[9px] font-mono font-semibold text-tibia-gold bg-black/40 backdrop-blur-sm border border-tibia-gold/25 px-1.5 py-0.5 rounded tracking-wider">${tierLabel}</span>

                    <!-- Área do Sprite (dominante) -->
                    <div class="relative h-32 bg-black/25 flex items-center justify-center border-b border-tibia-borderDark/15 overflow-hidden">
                        <div class="absolute inset-0" style="background: radial-gradient(circle at center, rgba(200,162,77,0.14), transparent 65%);"></div>
                        <img src="${monsterSpriteUrl}" onerror="handleBrokenImage(this)"
                            class="w-24 h-24 object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)] group-hover:scale-110 transition-transform duration-300 relative z-[1]"
                            alt="${m.name}" title="${m.name}">
                    </div>

                    <!-- Corpo do Card -->
                    <div class="p-3 flex flex-col flex-grow">
                        <h5 class="font-rpg text-sm text-tibia-gold font-bold uppercase tracking-wide text-center group-hover:text-white transition-colors leading-tight">${m.name}</h5>
                        <span class="text-[9px] text-tibia-muted font-sans font-medium uppercase tracking-wider block text-center mt-1">Lv: ${m.level_range || '150 - 500'}</span>

                        <!-- Linhas de estatística: HP e XP -->
                        <div class="mt-3 pt-2.5 border-t border-tibia-borderDark/15 space-y-1.5">
                            <div class="flex items-center justify-between gap-2 text-[11px]">
                                <span class="flex items-center gap-1.5 text-tibia-muted font-medium">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-3.5 h-3.5 text-emerald-400/80"><path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z"/></svg>
                                    HP
                                </span>
                                <strong class="font-mono tabular-nums text-emerald-400 text-xs">${Number(m.hp).toLocaleString('pt-BR')}</strong>
                            </div>
                            <div class="flex items-center justify-between gap-2 text-[11px] pt-1.5 border-t border-tibia-borderDark/10">
                                <span class="flex items-center gap-1.5 text-tibia-muted font-medium">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-3.5 h-3.5 text-tibia-gold/80"><path fill-rule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clip-rule="evenodd"/></svg>
                                    XP
                                </span>
                                <strong class="font-mono tabular-nums text-tibia-gold text-xs">+${Number(m.xp).toLocaleString('pt-BR')}</strong>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } else {
        grid.innerHTML = `<div class="col-span-full py-8 text-center text-tibia-muted text-xs">Nenhuma criatura encontrada neste Tier.</div>`;
    }
}

let activeItemTier = 'tier1';

window.changeWikiItemTier = function(tierName, cardEl) {
    const cards = document.querySelectorAll('.wiki-item-tier-card');
    cards.forEach(card => {
        card.classList.remove('active', 'bg-tibia-bg', 'border-tibia-gold/60', 'gold-glow');
        card.classList.add('bg-tibia-panel/60', 'border-tibia-borderDark/30');
        
        const title = card.querySelector('h4');
        if (title) {
            title.classList.remove('text-tibia-gold');
            title.classList.add('text-tibia-text');
        }
    });

    cardEl.classList.add('active', 'bg-tibia-bg', 'border-tibia-gold/60', 'gold-glow');
    cardEl.classList.remove('bg-tibia-panel/60', 'border-tibia-borderDark/30');
    
    const activeTitle = cardEl.querySelector('h4');
    if (activeTitle) {
        activeTitle.classList.remove('text-tibia-text');
        activeTitle.classList.add('text-tibia-gold');
    }

    activeItemTier = tierName;
    loadWikiContent();
};

let activeItemCategory = 'all';

window.changeWikiItemCategory = function(categoryName, buttonEl) {
    const buttons = document.querySelectorAll('.wiki-item-category-btn');
    buttons.forEach(btn => {
        btn.classList.remove('bg-tibia-border', 'text-tibia-bg', 'shadow');
        btn.classList.add('text-tibia-muted', 'hover:text-tibia-gold');
    });

    buttonEl.classList.add('bg-tibia-border', 'text-tibia-bg', 'shadow');
    buttonEl.classList.remove('text-tibia-muted', 'hover:text-tibia-gold');

    activeItemCategory = categoryName;
    loadWikiContent();
};

let cachedItemsData = [];
let currentItemSortField = 'attack'; // Padrão: Ataque
let currentItemSortOrder = 'desc'; // Padrão: Decrescente (maior primeiro)

window.toggleWikiItemSort = function(fieldName) {
    if (currentItemSortField === fieldName) {
        currentItemSortOrder = currentItemSortOrder === 'asc' ? 'desc' : 'asc';
    } else {
        currentItemSortField = fieldName;
        currentItemSortOrder = fieldName === 'name' ? 'asc' : 'desc';
    }

    // Atualiza ícones visuais nos cabeçalhos de ordenação
    ['name', 'attack', 'defense', 'armor'].forEach(id => {
        const el = document.getElementById(`sort-item-icon-${id}`);
        if (el) {
            el.innerHTML = '';
            el.className = 'ml-1 text-[9px] text-tibia-muted';
        }
    });

    const activeEl = document.getElementById(`sort-item-icon-${fieldName}`);
    if (activeEl) {
        activeEl.innerHTML = currentItemSortOrder === 'asc' ? '▲' : '▼';
        activeEl.className = 'ml-1 text-[9px] text-tibia-gold';
    }

    renderWikiItemsTable();
};

function renderWikiItemsTable() {
    const grid = document.getElementById('wiki-items-grid');
    if (!grid || !cachedItemsData) return;

    // Faz uma cópia para ordenar
    let sorted = [...cachedItemsData];

    sorted.sort((a, b) => {
        let valA, valB;
        if (currentItemSortField === 'name') {
            valA = a.name.toLowerCase();
            valB = b.name.toLowerCase();
        } else {
            valA = Number(a[currentItemSortField] || 0);
            valB = Number(b[currentItemSortField] || 0);
        }

        if (valA < valB) return currentItemSortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return currentItemSortOrder === 'asc' ? 1 : -1;
        return 0;
    });

    if (sorted.length > 0) {
        grid.innerHTML = sorted.map(item => {
            // Linhas de estatística relevantes (apenas os stats presentes)
            const statRows = [];
            if (item.attack > 0) statRows.push(`
                <div class="flex items-center justify-between gap-2 text-[11px]">
                    <span class="flex items-center gap-1.5 text-tibia-muted font-medium">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-3.5 h-3.5 text-red-400/80"><path fill-rule="evenodd" d="M11.47 3.84a.75.75 0 011.06 0l8.69 8.69a.75.75 0 010 1.06l-8.689 8.69a.75.75 0 01-1.06 0l-8.69-8.69a.75.75 0 010-1.06l8.69-8.69z" clip-rule="evenodd"/></svg>
                        Ataque
                    </span>
                    <strong class="font-mono tabular-nums text-red-400 text-xs">${item.attack}</strong>
                </div>`);
            if (item.defense > 0) statRows.push(`
                <div class="flex items-center justify-between gap-2 text-[11px] pt-1.5 border-t border-tibia-borderDark/10">
                    <span class="flex items-center gap-1.5 text-tibia-muted font-medium">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-3.5 h-3.5 text-emerald-400/80"><path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM12 6.75a5.25 5.25 0 100 10.5 5.25 5.25 0 000-10.5z" clip-rule="evenodd"/></svg>
                        Defesa
                    </span>
                    <strong class="font-mono tabular-nums text-emerald-400 text-xs">${item.defense}</strong>
                </div>`);
            if (item.armor > 0) statRows.push(`
                <div class="flex items-center justify-between gap-2 text-[11px] pt-1.5 border-t border-tibia-borderDark/10">
                    <span class="flex items-center gap-1.5 text-tibia-muted font-medium">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-3.5 h-3.5 text-amber-400/80"><path fill-rule="evenodd" d="M3.75 6.75h16.5a.75.75 0 01.75.75v3a.75.75 0 01-.75.75h-1.5v2.25H18a.75.75 0 01-.75.75H14.25a.75.75 0 01-.75-.75V11.25h-.75v6.75h2.25a.75.75 0 01.75.75v1.5a.75.75 0 01-.75.75h-6.5a.75.75 0 01-.75-.75v-1.5a.75.75 0 01.75-.75h2.25V11.25h-.75v3a.75.75 0 01-.75.75H6a.75.75 0 01-.75-.75V11.25h-1.5a.75.75 0 01-.75-.75v-3a.75.75 0 01.75-.75z" clip-rule="evenodd"/></svg>
                        Armadura
                    </span>
                    <strong class="font-mono tabular-nums text-amber-400 text-xs">${item.armor}</strong>
                </div>`);
            if (item.weight > 0) statRows.push(`
                <div class="flex items-center justify-between gap-2 text-[11px] pt-1.5 border-t border-tibia-borderDark/10">
                    <span class="flex items-center gap-1.5 text-tibia-muted font-medium">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="w-3.5 h-3.5 text-tibia-muted"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3a3 3 0 00-3 3v2.5M5.25 8.25h13.5a.75.75 0 01.75.75v9.75a2.25 2.25 0 01-2.25 2.25H6.75a2.25 2.25 0 01-2.25-2.25V9a.75.75 0 01.75-.75z"/></svg>
                        Peso
                    </span>
                    <strong class="font-mono tabular-nums text-tibia-text text-xs">${item.weight} oz</strong>
                </div>`);

            return `
                <div onclick="openWikiItemPopup('${escapeHTML(item.name)}')" class="bg-tibia-panel rounded-lg border border-tibia-borderDark/20 hover:border-tibia-gold/50 hover:shadow-xl transition-all cursor-pointer flex flex-col overflow-hidden group relative">
                    <!-- Área do Sprite (dominante) -->
                    <div class="relative h-32 bg-black/25 flex items-center justify-center border-b border-tibia-borderDark/15 overflow-hidden">
                        <div class="absolute inset-0" style="background: radial-gradient(circle at center, rgba(200,162,77,0.14), transparent 65%);"></div>
                        <img src="assets/items/${item.id}.png" onerror="handleBrokenImage(this)"
                            class="w-24 h-24 object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)] group-hover:scale-110 transition-transform duration-300 relative z-[1]"
                            alt="${item.name}" title="${item.name}">
                    </div>

                    <!-- Corpo do Card -->
                    <div class="p-3 flex flex-col flex-grow">
                        <h5 class="font-rpg text-sm text-tibia-gold font-bold uppercase tracking-wide text-center group-hover:text-white transition-colors leading-tight">${item.name}</h5>
                        <span class="text-[9px] text-tibia-muted font-sans font-medium uppercase tracking-wider block text-center mt-1">${item.slot}</span>

                        <!-- Linhas de estatística: stats do item -->
                        <div class="mt-3 pt-2.5 border-t border-tibia-borderDark/15 space-y-1.5">
                            ${statRows.length ? statRows.join('') : '<span class="block text-center text-[10px] text-tibia-muted italic">Sem atributos de combate.</span>'}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } else {
        grid.innerHTML = `<div class="col-span-full py-8 text-center text-tibia-muted text-xs">Nenhum equipamento encontrado nesta categoria.</div>`;
    }
}

window.loadWikiContent = function() {
    const monstersBody = document.getElementById('wiki-monsters-body');
    const searchInput = document.getElementById('wikiSearchInput');
    const query = searchInput ? searchInput.value.trim() : '';

    if (activeWikiCategory === 'monsters') {
        const monstersGrid = document.getElementById('wiki-monsters-grid');
        if (!monstersGrid) return;
        monstersGrid.innerHTML = `<div class="col-span-full py-8 text-center text-tibia-muted text-xs">Buscando bestas do templo...</div>`;
        
        fetch(`api/wiki.php?action=monsters&tier=${activeMonsterTier}&search=${encodeURIComponent(query)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.data) {
                    cachedMonstersData = data.data;
                    renderWikiMonstersTable();
                } else {
                    monstersGrid.innerHTML = `<div class="col-span-full py-8 text-center text-tibia-muted text-xs">Nenhuma criatura encontrada neste Tier.</div>`;
                }
            })
            .catch(() => {
                monstersGrid.innerHTML = `<div class="col-span-full py-8 text-center text-red-500 font-bold text-xs">Erro ao carregar bestiário.</div>`;
            });

    } else if (activeWikiCategory === 'items') {
        const itemsGrid = document.getElementById('wiki-items-grid');
        if (!itemsGrid) return;
        itemsGrid.innerHTML = `<div class="col-span-full py-8 text-center text-tibia-muted text-xs">Polindo equipamentos...</div>`;
        fetch(`api/wiki.php?action=items&tier=${activeItemTier}&category=${activeItemCategory}&search=${encodeURIComponent(query)}`)
            .then(res => res.json())
            .then(data => {
                if (data.success && data.data) {
                    cachedItemsData = data.data;
                    renderWikiItemsTable();
                } else {
                    itemsGrid.innerHTML = `<div class="col-span-full py-8 text-center text-tibia-muted text-xs">Nenhum equipamento encontrado.</div>`;
                }
            })
            .catch(() => {
                itemsGrid.innerHTML = `<div class="col-span-full py-8 text-center text-red-500 font-bold text-xs">Erro ao carregar catálogo do ferreiro.</div>`;
            });
    } else {
        // Sistemas Modulares (Pets, Comidas, Mineração)
        fetch('api/wiki.php?action=custom_systems')
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const system = data[activeWikiCategory];
                    document.getElementById('systemName').innerText = system.name;
                    document.getElementById('systemDesc').innerText = system.description;

                    const detailsContainer = document.getElementById('systemDetails');
                    if (activeWikiCategory === 'mining') {
                        detailsContainer.innerHTML = system.ores.map(o => `
                            <div class="bg-tibia-bg/50 p-4 border border-tibia-borderDark/15 rounded flex justify-between items-center gap-3">
                                <div>
                                    <span class="block font-semibold text-tibia-text font-rpg">${o.name}</span>
                                    <span class="text-[11px] text-tibia-muted">Chance: <strong class="text-tibia-gold">${o.chance}</strong></span>
                                </div>
                                <span class="text-xs text-emerald-400 font-mono font-bold">${o.reward}</span>
                            </div>
                        `).join('');
                    } else if (activeWikiCategory === 'pets') {
                        // Filtra os pets pelo Tier selecionado
                        const filteredPets = system.types.filter(p => Number(p.tier) === activePetTier);

                        detailsContainer.innerHTML = filteredPets.map(t => `
                            <div class="bg-tibia-panel p-5 border-2 border-tibia-borderDark/20 rounded-md space-y-3 hover:border-tibia-border/50 hover:shadow-lg transition-all">
                                <div class="flex justify-between items-start border-b border-tibia-borderDark/10 pb-2">
                                    <div>
                                        <h5 class="font-rpg text-base text-tibia-gold font-bold uppercase tracking-wide">${t.name}</h5>
                                        <span class="text-[10px] text-tibia-muted font-sans font-medium uppercase tracking-wider">${t.role}</span>
                                    </div>
                                    <span class="bg-tibia-bg border border-tibia-borderDark/30 text-tibia-gold text-[9px] px-2 py-0.5 rounded font-mono font-bold uppercase">TIER ${t.tier}</span>
                                </div>
                                <div class="space-y-1.5 text-xs">
                                    <div class="flex items-center gap-1.5 text-tibia-text">
                                        <span class="text-tibia-gold font-bold">Summon Item:</span>
                                        <span class="font-sans text-white font-medium">${t.summon_item}</span>
                                    </div>
                                    <div class="flex items-center gap-1.5 text-tibia-text">
                                        <span class="text-tibia-gold font-bold">HP Base:</span>
                                        <strong class="text-emerald-400 font-mono text-sm">${t.hp_base}</strong>
                                    </div>
                                    <div class="flex items-center gap-1.5 text-tibia-text">
                                        <span class="text-tibia-gold font-bold">Dano Médio:</span>
                                        <strong class="text-red-400 font-mono">${t.avg_damage}</strong>
                                    </div>
                                    <div class="pt-2 border-t border-tibia-borderDark/5">
                                        <span class="block text-tibia-gold font-bold mb-1">Função & Mecânica:</span>
                                        <p class="text-white text-xs leading-relaxed font-sans">${t.function_desc}</p>
                                    </div>
                                </div>
                            </div>
                        `).join('');
                    } else if (activeWikiCategory === 'upgrades') {
                        detailsContainer.innerHTML = system.mechanics.map(m => `
                            <div class="bg-tibia-bg/50 p-4 border border-tibia-borderDark/15 rounded space-y-1">
                                <span class="block font-semibold text-tibia-gold font-rpg uppercase text-xs tracking-wider">${m.name}</span>
                                <p class="text-xs text-tibia-text leading-relaxed">${m.details}</p>
                            </div>
                        `).join('');
                    } else if (activeWikiCategory === 'foods') {
                        detailsContainer.innerHTML = system.dishes.map(d => `
                            <div class="bg-tibia-bg/50 p-4 border border-tibia-borderDark/15 rounded space-y-1">
                                <span class="block font-semibold text-tibia-text font-rpg">${d.name}</span>
                                <p class="text-xs text-emerald-400 font-sans">${d.effect}</p>
                            </div>
                        `).join('');
                    }
                }
            });
    }
};

/* ==========================================
   5. CARD: LORE (CRÔNICAS)
   ========================================== */
function initLoreCapitulos() {
    const listContainer = document.getElementById('lore-list-container');
    const visualizador = document.getElementById('lore-viewer');
    if (!listContainer || !visualizador) return;

    fetch('api/lores.php?action=list')
        .then(res => res.json())
        .then(data => {
            if (data.success && data.lores && data.lores.length > 0) {
                renderLoreList(data.lores);
            } else {
                listContainer.innerHTML = '<p class="text-xs text-tibia-muted">Nenhum capítulo gravado.</p>';
            }
        });

    // Form de Admin para criar Lore
    const adminForm = document.getElementById('adminLoreForm');
    if (adminForm) {
        adminForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const title = document.getElementById('loreTitle').value;
            const content = document.getElementById('loreContent').value;

            fetch('api/lores.php?action=create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, content })
            })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    adminForm.reset();
                    initLoreCapitulos(); // Recarregar lores
                }
            })
            .catch(() => alert('Erro ao registrar crônica.'));
        });
    }
}

function renderLoreList(lores) {
    const listContainer = document.getElementById('lore-list-container');
    const visualizador = document.getElementById('lore-viewer');
    
    listContainer.innerHTML = lores.map((lore, index) => {
        const activeClass = index === 0 ? 'border-tibia-gold text-tibia-gold' : 'border-transparent text-tibia-muted';
        
        return `
            <button onclick="selectLore(${lore.id}, this)" data-id="${lore.id}" class="lore-cap-btn w-full text-left px-3 py-2 rounded text-sm border hover:border-tibia-gold transition-all ${activeClass}">
                <span>${lore.title}</span>
                <div class="lore-content-source hidden" id="lore-src-${lore.id}">
                    ${lore.content}
                </div>
            </button>
        `;
    }).join('');

    // Selecionar o primeiro elemento por padrão
    if (lores.length > 0) {
        selectLore(lores[0].id, listContainer.querySelector('.lore-cap-btn'));
    }
}

window.selectLore = function(id, btnEl) {
    const botoes = document.querySelectorAll('.lore-cap-btn');
    const visualizador = document.getElementById('lore-viewer');
    const source = document.getElementById(`lore-src-${id}`);

    botoes.forEach(b => {
        b.classList.remove('border-tibia-gold', 'text-tibia-gold');
        b.classList.add('border-transparent', 'text-tibia-muted');
    });

    if (btnEl) {
        btnEl.classList.add('border-tibia-gold', 'text-tibia-gold');
        btnEl.classList.remove('border-transparent', 'text-tibia-muted');
    }

    if (source && visualizador) {
        const titulo = btnEl.querySelector('span').textContent;
        visualizador.innerHTML = `
            <h4 class="font-rpg text-2xl text-tibia-gold font-bold tracking-wider mb-4 pb-2 border-b border-tibia-borderDark/30 text-center md:text-left">${titulo}</h4>
            <div class="text-sm text-tibia-muted leading-relaxed space-y-4">
                ${source.innerHTML}
            </div>
        `;

        visualizador.querySelectorAll('img').forEach(img => {
            img.onerror = () => handleBrokenImage(img);
        });
    }
};

/* ==========================================
   6. SISTEMA DE LOGOUT E ENCERRAMENTO DE SESSÃO
   ========================================== */
function initLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (!logoutBtn) return;

    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        
        if (confirm('Tem certeza de que deseja retornar para o templo e deslogar?')) {
            fetch('api/logout.php')
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = 'index.html';
                    } else {
                        window.location.href = 'index.html';
                    }
                })
                .catch(() => {
                    window.location.href = 'index.html';
                });
        }
    });
}

/* ==========================================
   7. SISTEMA DE TICKETS (SUPORTE AO JOGADOR)
   ========================================== */
document.addEventListener('DOMContentLoaded', () => {
    const newTicketForm = document.getElementById('newTicketForm');
    if (newTicketForm) {
        newTicketForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const title = document.getElementById('ticketTitle').value.trim();
            const category = document.getElementById('ticketCategory').value;
            const description = document.getElementById('ticketDescription').value.trim();

            fetch('api/tickets.php?action=create', {
                method: 'POST',
                headers: { 'Content-Type:': 'application/json' },
                body: JSON.stringify({ title, category, description })
            })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    newTicketForm.reset();
                    loadUserTickets();
                }
            })
            .catch(() => alert('Erro ao registrar chamado de suporte.'));
        });
    }
});

window.loadUserTickets = function() {
    const feed = document.getElementById('user-tickets-feed');
    if (!feed) return;

    feed.innerHTML = getLoaderHTML('Lendo seus tickets abertos...');

    fetch('api/tickets.php?action=list')
        .then(res => res.json())
        .then(data => {
            if (data.success && data.tickets && data.tickets.length > 0) {
                feed.innerHTML = data.tickets.map(t => {
                    const statusColors = {
                        'Aberto': 'bg-emerald-950/40 text-emerald-400 border-emerald-900/40',
                        'Em Atendimento': 'bg-sky-950/40 text-sky-400 border-sky-900/40',
                        'Resolvido': 'bg-amber-950/40 text-amber-400 border-amber-900/40',
                        'Fechado': 'bg-slate-950/40 text-slate-400 border-slate-900/40'
                    };
                    const statusClass = statusColors[t.status] || 'bg-slate-950/40 text-slate-400 border-slate-900/40';
                    
                    let replyHTML = '';
                    if (t.reply) {
                        replyHTML = `
                            <div class="mt-3 pt-3 border-t border-tibia-borderDark/10 bg-tibia-bg/60 p-3 rounded">
                                <span class="block text-[10px] font-bold text-tibia-gold uppercase tracking-wider">Resposta do GOD:</span>
                                <p class="text-white text-xs leading-relaxed mt-1 font-sans">${escapeHTML(t.reply)}</p>
                            </div>
                        `;
                    }

                    return `
                        <div class="bg-tibia-panel p-4 border-2 border-tibia-borderDark/15 rounded space-y-2">
                            <div class="flex justify-between items-start border-b border-tibia-borderDark/10 pb-2">
                                <div>
                                    <h5 class="font-rpg text-sm text-tibia-gold font-bold">${escapeHTML(t.title)}</h5>
                                    <span class="text-[9px] text-tibia-muted uppercase font-sans tracking-wide">Categoria: ${escapeHTML(t.category)}</span>
                                </div>
                                <span class="border px-2 py-0.5 rounded text-[8px] font-bold uppercase font-mono ${statusClass}">${t.status}</span>
                            </div>
                            <p class="text-xs text-tibia-text font-sans leading-relaxed">${escapeHTML(t.description)}</p>
                            ${replyHTML}
                            <span class="block text-[9px] text-tibia-muted font-mono pt-1">Aberto em: ${t.created_at}</span>
                        </div>
                    `;
                }).join('');
            } else {
                feed.innerHTML = `
                    <div class="text-center py-8 border border-dashed border-tibia-borderDark/20 rounded bg-tibia-bg/25">
                        <p class="text-xs text-tibia-muted">Você não possui nenhum chamado de suporte registrado.</p>
                    </div>
                `;
            }
        })
        .catch(() => {
            feed.innerHTML = `<p class="text-xs text-red-400 text-center py-6">Erro ao conectar à central de suporte.</p>`;
        });
};

/* ==========================================
   8. SISTEMA DE ADMINISTRAÇÃO (MÉTRICAS & TERMINAL)
   ========================================== */
window.loadAdminMetrics = function() {
    fetch('api/admin.php?action=metrics')
        .then(res => res.json())
        .then(data => {
            if (data.success && data.metrics) {
                const m = data.metrics;
                document.getElementById('admin-metric-online').innerText = m.players_online;
                document.getElementById('admin-metric-latency').innerText = m.db_latency_ms + ' ms';
                document.getElementById('admin-metric-accounts').innerText = m.total_accounts;
                document.getElementById('admin-metric-tickets').innerText = m.pending_tickets;
            }
        });
};

window.loadAdminConsoleLogs = function() {
    const terminal = document.getElementById('admin-console-output');
    if (!terminal) return;

    terminal.innerText = 'Carregando logs do executável do TFS...';

    fetch('api/admin.php?action=console_log')
        .then(res => res.json())
        .then(data => {
            if (data.success && data.logs) {
                terminal.innerText = data.logs;
                // Auto-scroll para o final dos logs
                const terminalParent = terminal.parentElement;
                if (terminalParent) terminalParent.scrollTop = terminalParent.scrollHeight;
            } else {
                terminal.innerText = 'Não foi possível ler o arquivo console.log do TFS.';
            }
        })
        .catch(() => {
            terminal.innerText = 'Erro de infraestrutura ao buscar logs do console.';
        });
};

window.loadAdminTickets = function() {
    const container = document.getElementById('admin-tickets-container');
    if (!container) return;

    container.innerHTML = getLoaderHTML('Lendo chamados abertos da fila...');

    fetch('api/tickets.php?action=list')
        .then(res => res.json())
        .then(data => {
            if (data.success && data.tickets && data.tickets.length > 0) {
                container.innerHTML = data.tickets.map(t => {
                    const statusColors = {
                        'Aberto': 'bg-emerald-950/40 text-emerald-400 border-emerald-900/40',
                        'Em Atendimento': 'bg-sky-950/40 text-sky-400 border-sky-900/40',
                        'Resolvido': 'bg-amber-950/40 text-amber-400 border-amber-900/40',
                        'Fechado': 'bg-slate-950/40 text-slate-400 border-slate-900/40'
                    };
                    const statusClass = statusColors[t.status] || 'bg-slate-950/40 text-slate-400 border-slate-900/40';

                    let replyFormHTML = '';
                    if (!t.reply) {
                        replyFormHTML = `
                            <div class="mt-3 pt-3 border-t border-tibia-borderDark/10 space-y-2">
                                <label class="block text-[10px] font-bold text-tibia-gold uppercase">Responder ao Jogador:</label>
                                <textarea id="reply-text-${t.id}" rows="2" placeholder="Digite a resposta do suporte..."
                                    class="w-full bg-tibia-bg border border-tibia-borderDark/60 rounded px-2.5 py-1.5 text-xs text-tibia-text focus:outline-none focus:border-tibia-gold transition-colors resize-none"></textarea>
                                <div class="flex gap-2">
                                    <button onclick="replyAdminTicket(${t.id}, 'Resolvido')" class="bg-tibia-border hover:bg-tibia-gold text-tibia-bg font-bold px-3 py-1 rounded text-[9px] uppercase tracking-wider transition-colors">Resolver</button>
                                    <button onclick="replyAdminTicket(${t.id}, 'Fechado')" class="bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-900/40 px-3 py-1 rounded text-[9px] uppercase tracking-wider transition-colors">Fechar Sem Resolver</button>
                                </div>
                            </div>
                        `;
                    } else {
                        replyFormHTML = `
                            <div class="mt-2 pt-2 border-t border-tibia-borderDark/10 text-[10px] text-tibia-muted">
                                <strong>Resposta enviada:</strong> ${escapeHTML(t.reply)}
                            </div>
                        `;
                    }

                    return `
                        <div class="bg-tibia-bg/60 p-4 border border-tibia-borderDark/25 rounded space-y-2">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h5 class="font-rpg text-xs text-tibia-gold font-bold">${escapeHTML(t.title)}</h5>
                                    <p class="text-[9px] text-tibia-muted">Aberto por: <strong class="text-white font-sans">${escapeHTML(t.account_name)}</strong> | Categoria: ${escapeHTML(t.category)}</p>
                                </div>
                                <span class="border px-2 py-0.5 rounded text-[8px] font-bold uppercase font-mono ${statusClass}">${t.status}</span>
                            </div>
                            <p class="text-xs text-tibia-text leading-relaxed font-sans">${escapeHTML(t.description)}</p>
                            ${replyFormHTML}
                            <span class="block text-[8px] text-tibia-muted font-mono pt-1">Enviado em: ${t.created_at}</span>
                        </div>
                    `;
                }).join('');
            } else {
                container.innerHTML = `
                    <div class="text-center py-8 border border-dashed border-tibia-borderDark/25 rounded bg-tibia-bg/25">
                        <p class="text-xs text-tibia-muted">Fila limpa! Nenhum chamado pendente de suporte.</p>
                    </div>
                `;
            }
        });
};

window.replyAdminTicket = function(ticketId, targetStatus) {
    const textEl = document.getElementById(`reply-text-${ticketId}`);
    const reply = textEl ? textEl.value.trim() : '';

    if (empty(reply)) {
        alert('Digite uma resposta válida para o jogador.');
        return;
    }

    fetch('api/tickets.php?action=reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticket_id: ticketId, reply: reply, status: targetStatus })
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            loadAdminTickets();
            loadAdminMetrics();
        }
    })
    .catch(() => alert('Erro de comunicação ao enviar resposta.'));
};

function empty(str) {
    return (!str || str.length === 0);
}

/* ==========================================
   HELPERS, SEGURANÇA E FALLBACK DE IMAGEM
   ========================================== */
window.handleBrokenImage = function(imgElement) {
    // Como o usuário baixou todos os sprites localmente, qualquer erro agora cai no fallback
    // de imagem transparente local para não quebrar a exibição do slot.
    imgElement.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"></svg>';
    imgElement.style.opacity = '0';
};

window.openWikiMonsterPopup = function(monsterName) {
    if (!cachedMonstersData) return;
    const m = cachedMonstersData.find(x => x.name.toLowerCase() === monsterName.toLowerCase());
    if (!m) return;

    const modal = document.getElementById('inspectModal');
    const titleEl = modal.querySelector('h3');
    const contentEl = document.getElementById('inspectModalContent');

    titleEl.innerText = `Detalhes da Criatura: ${m.name}`;

    const cleanName = m.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const spriteUrl = `assets/monsters/${cleanName}.gif`;

    // Construção rica do loot pool
    let lootRows = `<tr><td colspan="3" class="px-3 py-2 text-center text-tibia-muted text-xs italic">Nenhum espólio catalogado.</td></tr>`;
    if (m.loot && m.loot.length > 0) {
        lootRows = m.loot.map(l => `
            <tr class="border-b border-tibia-borderDark/10 hover:bg-tibia-bg/25">
                <td class="px-3 py-2 text-center">
                    <img src="assets/items/${l.itemid}.png" onerror="handleBrokenImage(this)" class="w-6 h-6 object-contain mx-auto" alt="${l.name}">
                </td>
                <td class="px-3 py-2 text-white font-medium text-xs">${l.name}</td>
                <td class="px-3 py-2 text-right font-mono text-tibia-gold text-xs">${l.chance}%</td>
            </tr>
        `).join('');
    }

    // Proporção de dano por vocação
    const pallyHp = m.paladin_hp || m.pally_hp || '--';
    const mageHp = m.mage_hp || '--';
    const knightHp = m.knight_hp || '--';

    contentEl.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            <!-- Coluna 1: Sprite e Dados Básicos (md: 4) -->
            <div class="md:col-span-4 bg-tibia-bg/60 p-4 border border-tibia-borderDark/25 rounded text-center flex flex-col items-center gap-3">
                <div class="w-24 h-24 bg-black/40 border border-tibia-borderDark/20 rounded flex items-center justify-center overflow-hidden">
                    <img src="${spriteUrl}" class="max-w-[80px] max-h-[80px] object-contain" alt="${m.name}">
                </div>
                <h4 class="font-rpg text-lg text-tibia-gold font-bold">${m.name}</h4>
                <span class="bg-tibia-panel border border-tibia-borderDark/20 text-tibia-muted text-[10px] px-2.5 py-0.5 rounded font-mono">TFS LOOKTYPE: ${m.looktype}</span>
                
                <div class="w-full text-left text-xs space-y-2 mt-2 pt-2 border-t border-tibia-borderDark/10">
                    <div class="flex justify-between"><span class="text-tibia-muted">Faixa de Level:</span> <strong class="text-white">${m.level_range || 'Iniciante'}</strong></div>
                    <div class="flex justify-between"><span class="text-tibia-muted">Pontos de Vida (HP):</span> <strong class="text-emerald-400 font-mono">${Number(m.hp).toLocaleString('pt-BR')}</strong></div>
                    <div class="flex justify-between"><span class="text-tibia-muted">Experiência (XP):</span> <strong class="text-tibia-gold font-mono">+${Number(m.xp).toLocaleString('pt-BR')}</strong></div>
                    <div class="flex justify-between"><span class="text-tibia-muted">Dano Máximo:</span> <strong class="text-red-400 font-mono">${m.max_dano || 'Varia'}</strong></div>
                </div>
            </div>

            <!-- Coluna 2: Informações de Combate e Dano Proporcional (md: 4) -->
            <div class="md:col-span-4 space-y-4">
                <div class="bg-tibia-bg/60 p-4 border border-tibia-borderDark/25 rounded">
                    <h5 class="text-xs font-bold text-tibia-gold uppercase tracking-wider border-b border-tibia-borderDark/20 pb-1.5 mb-2">Dano Proporcional (% HP)</h5>
                    <div class="space-y-2 text-xs">
                        <div class="flex justify-between items-center"><span class="text-tibia-muted">Mage / Druid:</span> <span class="font-mono font-bold text-red-400">${mageHp} do HP</span></div>
                        <div class="flex justify-between items-center"><span class="text-tibia-muted">Paladin:</span> <span class="font-mono font-bold text-amber-400">${pallyHp} do HP</span></div>
                        <div class="flex justify-between items-center"><span class="text-tibia-muted">Elite Knight:</span> <span class="font-mono font-bold text-emerald-400">${knightHp} do HP</span></div>
                    </div>
                </div>
                
                <div class="bg-tibia-bg/40 p-4 border border-tibia-borderDark/15 rounded text-xs leading-relaxed text-tibia-muted">
                    <span class="block text-tibia-gold font-bold mb-1 uppercase tracking-wide text-[10px]">Nota de Combate:</span>
                    O dano percentual reflete a periculosidade da criatura na arena de caça do IceYuriots, auxiliando no planejamento da hunt de acordo com o HP máximo de sua vocação.
                </div>
            </div>

            <!-- Coluna 3: Loot Table (md: 4) -->
            <div class="md:col-span-4 bg-tibia-bg/60 border border-tibia-borderDark/25 rounded overflow-hidden">
                <div class="bg-tibia-panel px-3 py-2 border-b border-tibia-borderDark/25">
                    <h5 class="text-xs font-bold text-tibia-gold uppercase tracking-wider">Tabela de Drops</h5>
                </div>
                <div class="max-h-[300px] overflow-y-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-black/30 border-b border-tibia-borderDark/10 text-[9px] text-tibia-muted uppercase tracking-wider">
                                <th class="px-3 py-1.5 text-center">Sprite</th>
                                <th class="px-3 py-1.5">Item</th>
                                <th class="px-3 py-1.5 text-right">Chance</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${lootRows}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;

    modal.classList.remove('hidden');
};

window.openWikiItemPopup = function(itemName) {
    if (!cachedItemsData) return;
    const item = cachedItemsData.find(x => x.name.toLowerCase() === itemName.toLowerCase());
    if (!item) return;

    const modal = document.getElementById('inspectModal');
    const titleEl = modal.querySelector('h3');
    const contentEl = document.getElementById('inspectModalContent');

    titleEl.innerText = `Detalhes do Item: ${item.name}`;

    // Construção das criaturas que dropam o item
    let dropRows = `<tr><td colspan="2" class="px-3 py-2 text-center text-tibia-muted text-xs italic">Não dropa de criaturas (Quest / Inicial).</td></tr>`;
    if (item.drops && item.drops.length > 0) {
        dropRows = item.drops.map(d => {
            const cleanDrop = d.monster.toLowerCase().replace(/[^a-z0-9]/g, '');
            const dropSprite = `assets/monsters/${cleanDrop}.gif`;
            return `
                <tr class="border-b border-tibia-borderDark/10 hover:bg-tibia-bg/25">
                    <td class="px-3 py-2">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 bg-black/30 border border-tibia-borderDark/20 rounded flex items-center justify-center shrink-0 overflow-hidden">
                                <img src="${dropSprite}" onerror="handleBrokenImage(this)" class="max-w-[24px] max-h-[24px] object-contain" alt="${d.monster}">
                            </div>
                            <span class="text-white font-medium text-xs font-rpg">${d.monster}</span>
                        </div>
                    </td>
                    <td class="px-3 py-2 text-right font-mono text-tibia-gold text-xs">${d.chance}%</td>
                </tr>
            `;
        }).join('');
    }

    let attrHTML = '';
    if (item.attack > 0) attrHTML += `<div class="flex justify-between border-b border-tibia-borderDark/10 pb-1.5"><span class="text-tibia-muted">Ataque:</span> <strong class="text-red-400 font-mono">${item.attack}</strong></div>`;
    if (item.defense > 0) attrHTML += `<div class="flex justify-between border-b border-tibia-borderDark/10 pb-1.5"><span class="text-tibia-muted">Defesa:</span> <strong class="text-emerald-400 font-mono">${item.defense}</strong></div>`;
    if (item.armor > 0) attrHTML += `<div class="flex justify-between border-b border-tibia-borderDark/10 pb-1.5"><span class="text-tibia-muted">Armadura:</span> <strong class="text-amber-400 font-mono">${item.armor}</strong></div>`;
    
    // Tratando IDs extras de balanceamento
    const classicId = item.id_860 || item.id;
    const newId = item.id_10 || '--';

    contentEl.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            <!-- Coluna 1: Sprite e Identificação (md: 4) -->
            <div class="md:col-span-4 bg-tibia-bg/60 p-4 border border-tibia-borderDark/25 rounded text-center flex flex-col items-center gap-3">
                <div class="w-20 h-20 bg-black/40 border border-tibia-borderDark/20 rounded flex items-center justify-center">
                    <img src="assets/items/${item.id}.png" onerror="handleBrokenImage(this)" class="w-12 h-12 object-contain" alt="${item.name}">
                </div>
                <h4 class="font-rpg text-lg text-tibia-gold font-bold">${item.name}</h4>
                <span class="bg-tibia-panel border border-tibia-borderDark/20 text-tibia-muted text-[10px] px-2 py-0.5 rounded font-mono">TFS ID: ${classicId}</span>
                
                <div class="w-full text-left text-xs space-y-2 mt-2 pt-2 border-t border-tibia-borderDark/10">
                    <div class="flex justify-between"><span class="text-tibia-muted">Client ID (10.0+):</span> <strong class="text-white font-mono">${newId}</strong></div>
                    <div class="flex justify-between"><span class="text-tibia-muted">Slot de Uso:</span> <strong class="text-white">${item.slot}</strong></div>
                    <div class="flex justify-between"><span class="text-tibia-muted">Peso:</span> <strong class="text-tibia-text font-mono">${item.weight} oz</strong></div>
                </div>
            </div>

            <!-- Coluna 2: Atributos Reais e Efeitos (md: 4) -->
            <div class="md:col-span-4 bg-tibia-bg/60 p-5 border border-tibia-borderDark/25 rounded flex flex-col justify-between min-h-[220px]">
                <div>
                    <h5 class="text-xs font-bold text-tibia-gold uppercase tracking-wider border-b border-tibia-borderDark/20 pb-1.5 mb-3">Atributos do Equipamento</h5>
                    <div class="space-y-2 text-xs">
                        ${attrHTML || `<div class="text-tibia-muted italic">Este item não possui atributos de combate físico diretos.</div>`}
                    </div>
                </div>
                <div class="mt-4 pt-3 border-t border-tibia-borderDark/10 text-xs">
                    <span class="block text-tibia-gold font-bold mb-1 uppercase tracking-wide text-[9px]">Efeito / Descrição:</span>
                    <p class="text-tibia-text italic">${item.description || 'Nenhum efeito mágico descrito.'}</p>
                </div>
            </div>

            <!-- Coluna 3: Fontes de Drop (md: 4) -->
            <div class="md:col-span-4 bg-tibia-bg/60 border border-tibia-borderDark/25 rounded overflow-hidden">
                <div class="bg-tibia-panel px-3 py-2 border-b border-tibia-borderDark/25">
                    <h5 class="text-xs font-bold text-tibia-gold uppercase tracking-wider">Fontes de Drops</h5>
                </div>
                <div class="max-h-[300px] overflow-y-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-black/30 border-b border-tibia-borderDark/10 text-[9px] text-tibia-muted uppercase tracking-wider">
                                <th class="px-3 py-1.5">Criatura Dropadora</th>
                                <th class="px-3 py-1.5 text-right">Chance</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${dropRows}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;

    modal.classList.remove('hidden');
};

window.closeInspectModal = function() {
    const modal = document.getElementById('inspectModal');
    if (modal) modal.classList.add('hidden');
};

function escapeHTML(str) {
    return str.replace(/[&<>'"]/g, 
        tag => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#39;',
            '"': '&quot;'
        }[tag] || tag)
    );
}

