<?php
/**
 * API de Tickets de Suporte e chamados - IceYuriots OT
 * Gerencia a abertura, listagem, e resposta de tickets de suporte pelo painel do site.
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/env.php';

session_start();

function getLoggedInAccountId() {
    return isset($_SESSION['account_id']) ? (int)$_SESSION['account_id'] : null;
}

function getWebGroup() {
    return isset($_SESSION['web_group']) ? (int)$_SESSION['web_group'] : 1;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list':
        $accountId = getLoggedInAccountId();
        if (!$accountId) {
            echo json_encode(['success' => false, 'message' => 'Você precisa estar logado para ver tickets.']);
            exit;
        }

        try {
            $userGroup = getWebGroup();
            
            // Se for Administrador (web_group >= 3), ele vê TODOS os tickets abertos do servidor
            if ($userGroup >= 3) {
                $stmt = $pdoWeb->query("
                    SELECT t.*, a.name AS account_name 
                    FROM web_tickets t
                    JOIN web_accounts a ON t.account_id = a.id
                    ORDER BY t.status ASC, t.created_at DESC
                ");
                $tickets = $stmt->fetchAll();
            } else {
                // Se for player comum, ele vê apenas os seus próprios tickets
                $stmt = $pdoWeb->prepare("
                    SELECT t.*, 'Você' AS account_name 
                    FROM web_tickets t
                    WHERE t.account_id = ?
                    ORDER BY t.created_at DESC
                ");
                $stmt->execute([$accountId]);
                $tickets = $stmt->fetchAll();
            }

            echo json_encode(['success' => true, 'tickets' => $tickets ?: []]);
        } catch (PDOException $e) {
            // Caso a tabela não exista localmente, criá-la silenciosamente
            try {
                $pdoWeb->exec("
                    CREATE TABLE IF NOT EXISTS `web_tickets` (
                        `id` INT AUTO_INCREMENT PRIMARY KEY,
                        `account_id` INT NOT NULL,
                        `title` VARCHAR(255) NOT NULL,
                        `category` VARCHAR(50) NOT NULL,
                        `description` TEXT NOT NULL,
                        `status` VARCHAR(20) DEFAULT 'Aberto',
                        `reply` TEXT DEFAULT NULL,
                        `replied_by` INT DEFAULT NULL,
                        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                ");
                echo json_encode(['success' => true, 'tickets' => []]);
            } catch (PDOException $ex) {
                echo json_encode(['success' => false, 'message' => 'Erro ao carregar chamados: ' . $e->getMessage()]);
            }
        }
        break;

    case 'create':
        $accountId = getLoggedInAccountId();
        if (!$accountId) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado. Faça login primeiro.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $title = isset($data['title']) ? htmlspecialchars(strip_tags(trim($data['title'])), ENT_QUOTES, 'UTF-8') : '';
        $category = isset($data['category']) ? htmlspecialchars(strip_tags(trim($data['category'])), ENT_QUOTES, 'UTF-8') : 'Geral';
        $description = isset($data['description']) ? htmlspecialchars(strip_tags(trim($data['description'])), ENT_QUOTES, 'UTF-8') : '';

        if (empty($title) || empty($description)) {
            echo json_encode(['success' => false, 'message' => 'Título e descrição do chamado são obrigatórios.']);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("
                INSERT INTO web_tickets (account_id, title, category, description, status) 
                VALUES (:account_id, :title, :category, :description, 'Aberto')
            ");
            $stmt->execute([
                'account_id' => $accountId,
                'title' => $title,
                'category' => $category,
                'description' => $description
            ]);
            echo json_encode(['success' => true, 'message' => 'Ticket de suporte aberto com sucesso! Um administrador responderá em breve.']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao registrar chamado: ' . $e->getMessage()]);
        }
        break;

    case 'reply':
        $accountId = getLoggedInAccountId();
        $userGroup = getWebGroup();

        // Apenas GOD/Admin pode responder tickets
        if (!$accountId || $userGroup < 3) {
            echo json_encode(['success' => false, 'message' => 'Acesso restrito apenas a administradores.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $ticketId = isset($data['ticket_id']) ? (int)$data['ticket_id'] : 0;
        $reply = isset($data['reply']) ? htmlspecialchars(strip_tags(trim($data['reply'])), ENT_QUOTES, 'UTF-8') : '';
        $status = isset($data['status']) ? htmlspecialchars(strip_tags(trim($data['status'])), ENT_QUOTES, 'UTF-8') : 'Resolvido';

        if ($ticketId <= 0 || empty($reply)) {
            echo json_encode(['success' => false, 'message' => 'Resposta vazia ou inválida.']);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("
                UPDATE web_tickets 
                SET reply = :reply, replied_by = :replied_by, status = :status 
                WHERE id = :id
            ");
            $stmt->execute([
                'reply' => $reply,
                'replied_by' => $accountId,
                'status' => $status,
                'id' => $ticketId
            ]);
            echo json_encode(['success' => true, 'message' => 'Ticket de suporte respondido e fechado!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao enviar resposta: ' . $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Ação não permitida.']);
        break;
}
