/**
 * Controlador de autenticação (Login e Cadastro) na página index.html
 */
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const authMessage = document.getElementById('authMessage');

    function showMessage(msg, ok) {
        authMessage.classList.remove('hidden');
        authMessage.textContent = msg;
        authMessage.className = 'mt-4 text-xs font-semibold text-center rounded p-3 border ' +
            (ok ? 'bg-emerald-950/40 text-emerald-400 border-emerald-900/40' : 'bg-red-950/40 text-red-400 border-red-900/40');
    }

    window.showAuthMode = function(mode, btnEl) {
        const isLogin = mode === 'login';
        loginForm.classList.toggle('hidden', !isLogin);
        registerForm.classList.toggle('hidden', isLogin);
        authMessage.classList.add('hidden');

        document.getElementById('toggleLoginBtn').className = 'flex-1 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all ' + (isLogin ? 'bg-tibia-border text-tibia-bg' : 'text-tibia-muted hover:text-tibia-gold');
        document.getElementById('toggleRegisterBtn').className = 'flex-1 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all ' + (isLogin ? 'text-tibia-muted hover:text-tibia-gold' : 'bg-tibia-border text-tibia-bg');
    };

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const account = document.getElementById('account').value;
            const password = document.getElementById('password').value;

            fetch('api/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ account, password })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    window.location.href = data.redirect;
                } else {
                    showMessage(data.message || 'Erro ao efetuar login.', false);
                }
            })
            .catch(() => showMessage('Erro de comunicação com o servidor.', false));
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const login = document.getElementById('regLogin').value;
            const password = document.getElementById('regPassword').value;

            fetch('api/register.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ login, password })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showMessage(data.message, true);
                    registerForm.reset();
                    // Após cadastrar, volta para o login com o login preenchido
                    document.getElementById('account').value = login;
                    setTimeout(() => showAuthMode('login', document.getElementById('toggleLoginBtn')), 1200);
                } else {
                    showMessage(data.message || 'Erro ao criar conta.', false);
                }
            })
            .catch(() => showMessage('Erro de comunicação com o servidor.', false));
        });
    }
});