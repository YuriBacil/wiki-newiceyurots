<?php
/**
 * API de Autenticação / Login - IceYuriots OT (VERSÃO DESACOPLADA E ROBUSTA)
 * Valida o login contra a tabela web_accounts (registros do próprio site).
 * Suporta senhas com hash forte (bcrypt) e, por compatibilidade, hashes SHA-1
 * antigos. Não possui contas privilegiadas embutidas nem backdoors.
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

// Configuração segura de sessão antes de iniciá-la
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método de requisição inválido.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$login = isset($data['account']) ? trim($data['account']) : '';
$password = isset($data['password']) ? (string)$data['password'] : '';

if ($login === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Login e senha são obrigatórios.']);
    exit;
}

try {
    $stmt = $pdoWeb->prepare("SELECT id, name, password AS pass_hash, web_group FROM web_accounts WHERE name = ?");
    $stmt->execute([$login]);
    $account = $stmt->fetch();

    if (!$account) {
        // Mensagem genérica para não revelar se o login existe
        echo json_encode(['success' => false, 'message' => 'Login ou senha inválidos.']);
        exit;
    }

    // Verificação da senha: bcrypt (novas) ou SHA-1 (legadas)
    $hash = $account['pass_hash'];
    $isValid = password_verify($password, $hash);
    if (!$isValid && !empty($hash) && strlen($hash) === 40 && strcasecmp($hash, sha1($password)) === 0) {
        $isValid = true;
        // Atualiza automaticamente o hash antigo para bcrypt
        $up = $pdoWeb->prepare("UPDATE web_accounts SET password = :h WHERE id = :id");
        $up->execute(['h' => password_hash($password, PASSWORD_DEFAULT), 'id' => (int)$account['id']]);
    }

    if (!$isValid) {
        echo json_encode(['success' => false, 'message' => 'Login ou senha inválidos.']);
        exit;
    }

    // Previne fixação de sessão: regenera o ID após autenticar
    session_regenerate_id(true);

    $_SESSION['account_id'] = (int)$account['id'];
    $_SESSION['account_name'] = $account['name'];
    $_SESSION['web_group'] = (int)$account['web_group'];

    echo json_encode([
        'success' => true,
        'redirect' => 'dashboard.html',
        'web_group' => (int)$account['web_group']
    ]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao conectar ao servidor de login.']);
}