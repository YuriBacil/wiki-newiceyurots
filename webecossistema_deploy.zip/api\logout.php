<?php
/**
 * API de Logout e Sessão para o IceYuriots OT
 * Limpa todos os dados da sessão corrente e redireciona de volta para a Home.
 */

session_start();

// Destruir todas as variáveis de sessão
$_SESSION = array();

// Se desejar destruir a sessão completamente, exclua também o cookie de sessão
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destruir a sessão em si
session_destroy();

// Retornar resposta JSON para o front-end saber que a sessão foi finalizada com sucesso
header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Sessão encerrada com sucesso.']);
exit;
