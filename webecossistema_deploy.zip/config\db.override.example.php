<?php
/**
 * EXEMPLO de sobrescrita de credenciais para HOSPEDAGEM REMOTA.
 *
 * COMO USAR:
 *   1. Copie este arquivo como  db.override.php  (no mesmo diretório config/).
 *   2. Preencha os valores com as credenciais fornecidas pelo seu host.
 *   3. Envie o arquivo junto com o site. O db.php o carrega automaticamente.
 *
 * OBSERVAÇÃO: Em hosts gratuitos, o nome do banco e o usuário costumam
 * vir com um prefixo. Exemplo (GoogieHost):  id1234567_web
 * Verifique no painel/phpMyAdmin do seu host os valores exatos.
 */

// Banco do SITE (leitura/escrita - PRIMÁRIO)
define('DB_WEB_HOST', 'localhost');
define('DB_WEB_PORT', '3306');
define('DB_WEB_NAME', 'COLE_O_NOME_DO_BANCO');
define('DB_WEB_USER', 'COLE_O_USUARIO');
define('DB_WEB_PASS', 'COLE_A_SENHA');
define('DB_WEB_CHARSET', 'utf8mb4');

// Banco do JOGO (somente importador local - no host remoto deixe igual ao site)
define('DB_GAME_HOST', 'localhost');
define('DB_GAME_PORT', '3306');
define('DB_GAME_NAME', 'COLE_O_NOME_DO_BANCO');
define('DB_GAME_USER', 'COLE_O_USUARIO');
define('DB_GAME_PASS', 'COLE_A_SENHA');
define('DB_GAME_CHARSET', 'utf8mb4');