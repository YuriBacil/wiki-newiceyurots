<?php
/**
 * IMPORTADOR / SYNC - IceYuriots OT
 * Lê os dados do servidor (arquivos do TFS + banco do jogo) e copia snapshots
 * para o banco EXCLUSIVO do site (web). O site roda 100% isolado a partir daqui.
 *
 * Como usar:
 *   php api/sync.php                      -> importa tudo
 *   php api/sync.php full                 -> importa tudo (alias)
 *   php api/sync.php accounts             -> só contas
 *   php api/sync.php items                -> só itens
 *   php api/sync.php monsters             -> só monstros
 *   php api/sync.php players              -> só players/snapshot
 *   php api/sync.php systems              -> só sistemas custom
 *   php api/sync.php schema               -> só cria/atualiza as tabelas
 *
 * Pode ser chamado via browser (XAMPP) ou via cron/CLI.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/doc_parser.php';

header('Content-Type: application/json; charset=utf-8');

$action = isset($_SERVER['argv'][1]) ? $_SERVER['argv'][1] : (isset($_GET['action']) ? $_GET['action'] : 'full');

$results = [];
$start = microtime(true);

// Garante que o banco do site existe com todas as tabelas
function ensureSchema($pdoWeb) {
    $schemaFile = __DIR__ . '/../db/web_schema.sql';
    if (!file_exists($schemaFile)) return 'schema file not found';
    $sql = file_get_contents($schemaFile);
    $pdoWeb->exec($sql);
    return 'schema ok';
}

// ---------------------------------------------------------------
// 1. CONTAS (login + hierarquia)
// ---------------------------------------------------------------
function syncAccounts($pdo, $pdoWeb) {
    if (!$pdo) return 'skip: jogo indisponível';
    $rows = $pdo->query("SELECT id, name, password, COALESCE(web_group,1) AS web_group, created FROM accounts")->fetchAll();
    $stmt = $pdoWeb->prepare(
        "INSERT INTO web_accounts (id, name, password, web_group, created) VALUES (:id,:name,:pw,:wg,:created)
         ON DUPLICATE KEY UPDATE name=VALUES(name), password=VALUES(password), web_group=VALUES(web_group), created=VALUES(created)"
    );
    $pdoWeb->beginTransaction();
    foreach ($rows as $r) {
        $stmt->execute([
            'id' => (int)$r['id'],
            'name' => $r['name'],
            'pw' => $r['password'],
            'wg' => (int)$r['web_group'],
            'created' => (int)$r['created']
        ]);
    }
    $pdoWeb->commit();
    return 'ok: ' . count($rows) . ' contas';
}

// ---------------------------------------------------------------
// 2. ITENS (parse do items.xml + docs de balanceamento)
// ---------------------------------------------------------------
function getTierItemsAllowed() {
    return [
        'tier1' => [
            'spellbook', 'spellbook of enlightenment',
            'wooden shield', 'studded shield', 'plate shield', 'bone shield', 'cooper shield', 'brass shield', 'steel shield', 'salamander shield', 'battle shield', 'sentinel shield', 'tusk shield',
            'coat', 'simples dress', 'white dress', 'girl\'s dress', 'tunic', 'summer dress', 'hibiscus dress', 'cape', 'jacket', 'spectral dress', 'red tunic', 'red robe', 'green tunic', 'belted cape', 'magician\'s robe',
            'leather helmet', 'brass helmet', 'studded helmet', 'post officers hat', 'mage hat', 'party hat', 'mystic turban', 'bandana', 'chain helmet', 'helmet of the deep', 'dark helmet', 'soldier helmet', 'viking helmet', 'damaged steel helmet',
            'sandals', 'leather boots', 'crocodile boots', 'fur boots', 'bunny slippers',
            'leather legs', 'studded legs', 'bast skirt', 'chain legs', 'brass legs',
            'hatchet', 'hand axe', 'axe', 'double axe', 'daramanian axe', 'halberd', 'barbarian axe', 'battle axe', 'sickle',
            'knife', 'dagger', 'combat knife', 'poison dagger', 'silver dagger', 'short sword', 'rapier', 'sabre', 'machete', 'sword', 'scimitar', 'heavy machete', 'bone sword', 'carlin sword', 'longsword',
            'club', 'crowbar', 'battle hammer', 'studded club', 'mace', 'morning star', 'furry club', 'iron hammer', 'bone club', 'staff', 'mammoth whopper', 'war hammer', 'giant smithhammer', 'daramanian mace', 'clerical mace',
            'arrow', 'bolt', 'small stone', 'spear', 'throwing knife', 'bow', 'crossbow',
            'cotonete', 'snakebite rod', 'moonlight rod', 'necrotic rod', 'wand of vortex', 'wand of dragonbreath', 'wand of decay'
        ],
        'tier2' => [
            'spellbook novice', 'spellbook of mind control',
            'dark shield', 'dwarven shield', 'scarab shield', 'guardian shield', 'dragon shield', 'tower shield', 'tortoise shield', 'viking shield', 'vampire shield',
            'doublet', 'leather armor', 'studded armor', 'chain armor', 'scale armor', 'ranger\'s cloak', 'brass armor', 'dark armor', 'ball gown', 'plate armor', 'spirit cloak', 'lightning robe', 'glacier robe', 'magma robe', 'terra mantle',
            'earmuffs', 'tribal mask', 'stranger helmet', 'iron helmet', 'legion helmet', 'feather headress', 'flower wreath', 'hat of the mad', 'mining helmet', 'fur hood', 'steel helmet', 'devil helmet', 'crown helmet', 'warrior helmet',
            'glacier shoes', 'magma boots', 'terra boots', 'lightning boots', 'steel boots',
            'plate legs', 'fur shorts', 'ranger legs', 'lightning legs', 'glacier shorts',
            'orcish axe', 'guardian halberd', 'daramanian waraxe', 'naginata', 'headchopper', 'heroic axe', 'glorious axe', 'royal axe', 'doublet axe', 'obsidian lance', 'dragon lance', 'golden sickle',
            'jagged sword', 'spike sword', 'bright sword', 'crimson sword', 'two handed sword', 'serpent sword', 'broadsword', 'katana', 'damaged crimson sword', 'epee', 'blacksteel sword', 'crystal sword', 'dreaded cleaver', 'ice rapier',
            'dragon hammer', 'crystal mace', 'diamond sceptre', 'orcish maul', 'dragonbone staff', 'brutetamer\'s staff', 'amber staff', 'taurus mace', 'cranial basher', 'lich staff',
            'onyx arrow', 'sniper arrow', 'piercing bolt', 'hunting spear', 'throwing star',
            'elvish bow', 'composite hornbow', 'modified crossbow', 'the ironwolker',
            'wand of draconia', 'wand of cosmic energy', 'wand of inferno',
            'northwind rod', 'terra rod', 'hailstorm rod'
        ],
        'tier3' => [],
        'tier4' => [],
        'raros' => []
    ];
}

function syncItems($pdoWeb) {
    if (!defined('TFS_PATH')) return 'skip: sem TFS_PATH';
    $itemsFile = TFS_PATH . '/data/items/items.xml';
    if (!file_exists($itemsFile)) return 'skip: items.xml não encontrado';

    $allowedByTier = getTierItemsAllowed();
    $docItems = DocParser::getItemsTier1();

    $xml = @simplexml_load_file($itemsFile);
    if (!$xml) return 'skip: items.xml inválido';

    $pdoWeb->exec("DELETE FROM web_items; DELETE FROM web_item_drops;");
    $insItem = $pdoWeb->prepare(
        "INSERT INTO web_items (id,name,attack,defense,armor,weight,slot,description,tier,category,id_860,id_10,attributes_desc)
         VALUES (:id,:name,:attack,:defense,:armor,:weight,:slot,:desc,:tier,:category,:id860,:id10,:attrs)"
    );
    $insDrop = $pdoWeb->prepare(
        "INSERT INTO web_item_drops (item_id,monster,chance) VALUES (:item_id,:monster,:chance)"
    );

    $count = 0;
    $pdoWeb->beginTransaction();
    foreach ($xml->item as $item) {
        $id = (int)$item['id'];
        $fromId = (int)$item['fromid'];
        $name = (string)$item['name'];
        if (empty($name)) continue;
        $nameLower = strtolower($name);
        if ($id === 0 && $fromId > 0) $id = $fromId;
        if ($id === 0) continue;

        $attack = $defense = $armor = 0;
        $weight = 0; $description = ''; $slotType = 'Nenhum'; $weaponType = '';
        foreach ($item->attribute as $attr) {
            $k = (string)$attr['key']; $v = (string)$attr['value'];
            if ($k === 'attack') $attack = (int)$v;
            elseif ($k === 'defense') $defense = (int)$v;
            elseif ($k === 'armor') $armor = (int)$v;
            elseif ($k === 'weight') $weight = (float)$v / 100;
            elseif ($k === 'description') $description = $v;
            elseif ($k === 'slotType') $slotType = ucfirst($v);
            elseif ($k === 'weaponType') $weaponType = strtolower($v);
        }

        // Classificação do slot
        $slot = classifyItemSlot($nameLower, $id, $slotType, $weaponType);
        $category = 'all';

        // Determinar tier pelo dicionário
        $tier = null;
        foreach ($allowedByTier as $t => $list) {
            if (in_array($nameLower, $list)) { $tier = $t; break; }
        }
        if ($tier === null) continue; // item não pertence ao balanceamento

        // Dados de balanceamento dos docs
        $id860 = 0; $id10 = 0; $attrs = '';
        if (isset($docItems[$nameLower])) {
            $id860 = $docItems[$nameLower]['id_860'];
            $id10 = $docItems[$nameLower]['id_10'];
            $attrs = $docItems[$nameLower]['attributes'];
        }

        $insItem->execute([
            'id' => $id, 'name' => $name, 'attack' => $attack, 'defense' => $defense,
            'armor' => $armor, 'weight' => $weight, 'slot' => $slot, 'desc' => $description,
            'tier' => $tier, 'category' => $category, 'id860' => $id860, 'id10' => $id10,
            'attrs' => $attrs
        ]);

        // Drops dos docs
        if (isset($docItems[$nameLower]['drops'])) {
            foreach ($docItems[$nameLower]['drops'] as $d) {
                $insDrop->execute(['item_id' => $id, 'monster' => $d['monster'], 'chance' => $d['chance']]);
            }
        }
        $count++;
    }
    $pdoWeb->commit();
    return 'ok: ' . $count . ' itens';
}

function classifyItemSlot($nameLower, $id, $slotType, $weaponType) {
    $isWand = strpos($nameLower, 'wand') !== false || in_array($id, [2437, 8921, 2189, 2187]);
    $isRod = strpos($nameLower, 'rod') !== false || in_array($id, [8911, 2181, 2183]);
    $isSword = $weaponType === 'sword' || strpos($nameLower, 'sword') !== false;
    $isAxe = $weaponType === 'axe' || strpos($nameLower, 'axe') !== false;
    $isClub = $weaponType === 'club' || strpos($nameLower, 'club') !== false || strpos($nameLower, 'mace') !== false;
    $isBow = strpos($nameLower, 'bow') !== false && strpos($nameLower, 'crossbow') === false;
    $isCrossbow = strpos($nameLower, 'crossbow') !== false;
    $isSpear = $weaponType === 'distance' || strpos($nameLower, 'spear') !== false;
    $isAmmo = strpos($nameLower, 'arrow') !== false || strpos($nameLower, 'bolt') !== false;
    $isHelmet = strpos($nameLower, 'helmet') !== false || strpos($nameLower, 'hat') !== false || strpos($nameLower, 'turban') !== false || strpos($nameLower, 'cap') !== false;
    $isArmor = strpos($nameLower, 'armor') !== false || strpos($nameLower, 'cloak') !== false || strpos($nameLower, 'robe') !== false || strpos($nameLower, 'dress') !== false || strpos($nameLower, 'tunic') !== false || strpos($nameLower, 'jacket') !== false || strpos($nameLower, 'coat') !== false;
    $isLegs = strpos($nameLower, 'legs') !== false || strpos($nameLower, 'shorts') !== false || strpos($nameLower, 'skirt') !== false;
    $isBoots = strpos($nameLower, 'boots') !== false || strpos($nameLower, 'shoes') !== false || strpos($nameLower, 'slippers') !== false;
    $isShield = strpos($nameLower, 'shield') !== false;
    $isSpellbook = strpos($nameLower, 'spellbook') !== false;

    if ($isWand) return 'Wand';
    if ($isRod) return 'Rod';
    if ($isSword) return 'Sword';
    if ($isAxe) return 'Axe';
    if ($isClub) return 'Club';
    if ($isBow) return 'Bow';
    if ($isCrossbow) return 'Crossbow';
    if ($isSpear) return 'Spear';
    if ($isAmmo) return 'Ammo';
    if ($isHelmet) return 'Helmet';
    if ($isArmor) return 'Armor';
    if ($isLegs) return 'Legs';
    if ($isBoots) return 'Boots';
    if ($isShield) return 'Shield';
    if ($isSpellbook) return 'Spellbook';
    return 'Equipamento';
}

// ---------------------------------------------------------------
// 3. MONSTROS (parse do monsters.xml + docs de balanceamento)
// ---------------------------------------------------------------
function getTierMonstersAllowed() {
    return [
        'tier1' => [
            'rat', 'cave rat', 'spider', 'bug', 'primitive', 'wild warrior',
            'frog (orchid)', 'badger', 'skunk', 'stalker', 'wasp', 'crazed beggar', 'tortoise',
            'skeleton', 'skeleton warrior', 'fire devil', 'penguin', 'ghoul', 'crypt shambler',
            'amazon', 'valkyrie', 'cyclops', 'nomad', 'mutated human', 'mutated rat',
            'chakoya (windcaller)', 'stone golem', 'gang member', 'smuggler', 'scarab', 'larva',
            'gladiator', 'gazer', 'beholder', 'bog raider', 'priestess', 'novice of the cult',
            'polar bear', 'winter wolf', 'carniphila', 'spit nettle', 'gozzler', 'zombie', 'nightstalker'
        ],
        'tier2' => [
            'bat', 'bear', 'snake', 'toad', 'black sheep', 'cobra', 'sandcrawler', 'centipede',
            'mummy', 'scorpion', 'troll', 'terror bird', 'terramite', 'demon skeleton', 'slime',
            'tiger', 'elephant', 'mammoth', 'hyaena', 'lion', 'ghost', 'crocodile', 'panda',
            'mutated tiger', 'mutated bat', 'rotworm', 'carrion rotworm', 'queen rotworm',
            'frost troll', 'swamp troll', 'troll champion', 'dworc venomspider', 'dworc fleshhunter',
            'dworc voodoomaster', 'wolf', 'war wolf', 'were wolf', 'dark magician', 'dark apprentice',
            'kongra', 'sibang', 'merlkin', 'gargoyle', 'blood crab', 'thornback tortoise',
            'elder beholder', 'braindeath', 'insect swarm', 'gnarlhound', 'worker golem', 'war golem'
        ],
        'tier3' => [],
        'tier4' => [],
        'bosses' => ['aegis', 'toxiros']
    ];
}

function syncMonsters($pdoWeb) {
    if (!defined('TFS_PATH')) return 'skip: sem TFS_PATH';
    $monstersFile = TFS_PATH . '/data/monster/monsters.xml';
    if (!file_exists($monstersFile)) return 'skip: monsters.xml não encontrado';

    $tiersAllowed = getTierMonstersAllowed();
    $docMonsters = DocParser::getMonstersTier1();

    // itemid -> nome para o loot
    $itemsFile = TFS_PATH . '/data/items/items.xml';
    $idToName = [];
    if (file_exists($itemsFile)) {
        $ix = @simplexml_load_file($itemsFile);
        if ($ix) foreach ($ix->item as $it) {
            $iid = (int)$it['id'];
            if ($iid && !empty((string)$it['name'])) $idToName[$iid] = (string)$it['name'];
        }
    }

    $xml = @simplexml_load_file($monstersFile);
    if (!$xml) return 'skip: monsters.xml inválido';

    $pdoWeb->exec("DELETE FROM web_monsters; DELETE FROM web_monster_loot;");
    $insMon = $pdoWeb->prepare(
        "INSERT INTO web_monsters (name,tier,hp,xp,speed,looktype,level_range,max_dano,mage_hp,pally_hp,knight_hp)
         VALUES (:name,:tier,:hp,:xp,:speed,:looktype,:level_range,:max_dano,:mage_hp,:pally_hp,:knight_hp)"
    );
    $insLoot = $pdoWeb->prepare(
        "INSERT INTO web_monster_loot (monster_id,itemid,name,chance,countmax) VALUES (:monster_id,:itemid,:name,:chance,:countmax)"
    );

    $count = 0;
    $pdoWeb->beginTransaction();
    foreach ($xml->monster as $m) {
        $name = (string)$m['name'];
        $file = (string)$m['file'];
        $nameLower = strtolower($name);
        if (empty($name)) continue;
        if (strpos($file, 'pets/') !== false) continue;

        $tier = null;
        foreach ($tiersAllowed as $t => $list) {
            if (in_array($nameLower, $list)) { $tier = $t; break; }
        }
        if ($tier === null) continue;

        $monsterXmlFile = TFS_PATH . '/data/monster/' . $file;
        $hp = $xp = $speed = $looktype = 0;
        $loot = [];
        if (file_exists($monsterXmlFile)) {
            $mXml = @simplexml_load_file($monsterXmlFile);
            if ($mXml) {
                $xp = (int)$mXml['experience'];
                $speed = (int)$mXml['speed'];
                if (isset($mXml->health)) $hp = (int)$mXml->health['max'];
                if (isset($mXml->look)) $looktype = (int)$mXml->look['type'];
                if (isset($mXml->loot->item)) {
                    foreach ($mXml->loot->item as $li) {
                        $iid = (int)$li['id'];
                        $chance = round((int)$li['chance'] / 1000, 2);
                        $loot[] = [
                            'itemid' => $iid,
                            'name' => isset($idToName[$iid]) ? $idToName[$iid] : 'Item ID ' . $iid,
                            'chance' => $chance,
                            'countmax' => isset($li['countmax']) ? (int)$li['countmax'] : 1
                        ];
                    }
                }
            }
        }

        $levelRange = $maxDano = $mageHp = $pallyHp = $knightHp = null;
        if (isset($docMonsters[$nameLower])) {
            $d = $docMonsters[$nameLower];
            $levelRange = $d['level_range'];
            $maxDano = $d['max_dano'];
            $mageHp = $d['mage_hp'];
            $pallyHp = $d['pally_hp'];
            $knightHp = $d['knight_hp'];
            if (!empty($d['loot'])) {
                $loot = [];
                foreach ($d['loot'] as $rl) {
                    $iid = isset($idToName) ? array_search($rl['name'], $idToName) : false;
                    $iid = $iid === false ? 0 : $iid;
                    $loot[] = [
                        'itemid' => $iid,
                        'name' => $rl['name'],
                        'chance' => (float)$rl['chance'],
                        'countmax' => isset($rl['max']) ? (int)$rl['max'] : 1
                    ];
                }
            }
        }

        $insMon->execute([
            'name' => $name, 'tier' => $tier, 'hp' => $hp, 'xp' => $xp, 'speed' => $speed,
            'looktype' => $looktype, 'level_range' => $levelRange, 'max_dano' => $maxDano,
            'mage_hp' => $mageHp, 'pally_hp' => $pallyHp, 'knight_hp' => $knightHp
        ]);
        $monsterId = $pdoWeb->lastInsertId();
        foreach ($loot as $l) {
            $insLoot->execute([
                'monster_id' => $monsterId, 'itemid' => $l['itemid'], 'name' => $l['name'],
                'chance' => $l['chance'], 'countmax' => $l['countmax']
            ]);
        }
        $count++;
        if ($count >= 60) break;
    }
    $pdoWeb->commit();
    return 'ok: ' . $count . ' monstros';
}

// ---------------------------------------------------------------
// 4. PLAYERS (snapshot do banco do jogo)
// ---------------------------------------------------------------
function syncPlayers($pdo, $pdoWeb) {
    if (!$pdo) return 'skip: jogo indisponível';

    $resetKey = 378378;

    $players = $pdo->query(
        "SELECT p.id, p.account_id, p.name, p.level, p.vocation, p.sex, p.group_id,
                p.experience, p.maglevel, p.skill_fist, p.skill_club, p.skill_sword,
                p.skill_axe, p.skill_dist, p.skill_shielding, p.healthmax, p.manamax,
                p.balance, p.lastlogin,
                EXISTS(SELECT 1 FROM players_online WHERE player_id = p.id) AS online,
                COALESCE((SELECT value FROM player_storage WHERE player_id = p.id AND `key` = {$resetKey}), 0) AS resets
         FROM players p
         ORDER BY p.id"
    )->fetchAll();

    $pdoWeb->exec("DELETE FROM web_players; DELETE FROM web_player_items; DELETE FROM web_player_deaths;");

    $insPlayer = $pdoWeb->prepare(
        "INSERT INTO web_players (id,account_id,name,level,vocation,sex,group_id,online,experience,maglevel,
          skill_fist,skill_club,skill_sword,skill_axe,skill_dist,skill_shielding,healthmax,manamax,balance,lastlogin,resets,guild_name,guild_rank,account_created)
         VALUES (:id,:account_id,:name,:level,:vocation,:sex,:group_id,:online,:experience,:maglevel,
          :skill_fist,:skill_club,:skill_sword,:skill_axe,:skill_dist,:skill_shielding,:healthmax,:manamax,:balance,:lastlogin,:resets,:guild_name,:guild_rank,:account_created)"
    );
    $insItem = $pdoWeb->prepare("INSERT INTO web_player_items (player_id,pid,itemtype,count) VALUES (:player_id,:pid,:itemtype,:count)");
    $insDeath = $pdoWeb->prepare("INSERT INTO web_player_deaths (player_id,level,time,killed_by,is_player) VALUES (:player_id,:level,:time,:killed_by,:is_player)");

    // Índices auxiliares
    $guildMap = [];
    $gq = $pdo->query(
        "SELECT gm.player_id, g.name AS guild_name, r.name AS rank_name
         FROM guild_membership gm
         INNER JOIN guilds g ON gm.guild_id = g.id
         INNER JOIN guild_ranks r ON gm.rank_id = r.id"
    );
    foreach ($gq->fetchAll() as $g) $guildMap[(int)$g['player_id']] = $g;

    $accCreatedMap = [];
    $aq = $pdo->query("SELECT id, created FROM accounts");
    foreach ($aq->fetchAll() as $a) $accCreatedMap[(int)$a['id']] = (int)$a['created'];

    $count = 0;
    $pdoWeb->beginTransaction();
    foreach ($players as $p) {
        $pid = (int)$p['id'];
        $g = isset($guildMap[$pid]) ? $guildMap[$pid] : null;
        $insPlayer->execute([
            'id' => $pid, 'account_id' => (int)$p['account_id'], 'name' => $p['name'],
            'level' => (int)$p['level'], 'vocation' => (int)$p['vocation'], 'sex' => (int)$p['sex'],
            'group_id' => (int)$p['group_id'], 'online' => (int)$p['online'],
            'experience' => (int)$p['experience'], 'maglevel' => (int)$p['maglevel'],
            'skill_fist' => (int)$p['skill_fist'], 'skill_club' => (int)$p['skill_club'],
            'skill_sword' => (int)$p['skill_sword'], 'skill_axe' => (int)$p['skill_axe'],
            'skill_dist' => (int)$p['skill_dist'], 'skill_shielding' => (int)$p['skill_shielding'],
            'healthmax' => (int)$p['healthmax'], 'manamax' => (int)$p['manamax'],
            'balance' => (int)$p['balance'], 'lastlogin' => (int)$p['lastlogin'],
            'resets' => (int)$p['resets'],
            'guild_name' => $g ? $g['guild_name'] : null,
            'guild_rank' => $g ? $g['rank_name'] : null,
            'account_created' => isset($accCreatedMap[(int)$p['account_id']]) ? $accCreatedMap[(int)$p['account_id']] : 0
        ]);

        // Equipamentos (slots 1-10)
        $iStmt = $pdo->prepare("SELECT pid, itemtype, count FROM player_items WHERE player_id = ? AND pid BETWEEN 1 AND 10");
        $iStmt->execute([$pid]);
        foreach ($iStmt->fetchAll() as $it) {
            $insItem->execute(['player_id' => $pid, 'pid' => (int)$it['pid'], 'itemtype' => (int)$it['itemtype'], 'count' => (int)$it['count']]);
        }

        // Mortes (todas, para contagem de frags / mundo)
        $dStmt = $pdo->prepare("SELECT level, time, killed_by, is_player FROM player_deaths WHERE player_id = ?");
        $dStmt->execute([$pid]);
        foreach ($dStmt->fetchAll() as $d) {
            $insDeath->execute([
                'player_id' => $pid, 'level' => (int)$d['level'], 'time' => (int)$d['time'],
                'killed_by' => $d['killed_by'], 'is_player' => (int)$d['is_player']
            ]);
        }
        $count++;
    }
    $pdoWeb->commit();
    return 'ok: ' . $count . ' players';
}

// ---------------------------------------------------------------
// 5. SISTEMAS CUSTOM (configuração em JSON)
// ---------------------------------------------------------------
function syncSystems($pdoWeb) {
    $systems = [
        'mining' => [
            'name' => 'Sistema de Mineração Dinâmica',
            'description' => 'Colete minérios preciosos batendo com sua Pickaxe nas veias de carvão e cristal do subsolo do IceYuriots.',
            'ores' => [
                ['name' => 'Coal Ore (Carvão)', 'chance' => '45%', 'reward' => '100 gp + Crafting Exp'],
                ['name' => 'Iron Ore (Ferro)', 'chance' => '25%', 'reward' => 'Iron Bars para Tier Upgrades'],
                ['name' => 'Gold Ore (Ouro)', 'chance' => '10%', 'reward' => 'Moedas de Ouro'],
                ['name' => 'Crystal Gem (Cristal)', 'chance' => '2.5%', 'reward' => 'Gemas de Despertar de Armas (Awakening)']
            ]
        ],
        'pets' => [
            'name' => 'Pet System (Summons de Bolso)',
            'description' => 'O Pet System permite que você invoque criaturas aliadas (Mascotes de Bolso) que auxiliam em combate atacando, curando ou servindo como escudo humano (tancando). Ao usar o item correspondente, o mascote é sumonado ao seu lado. O HP máximo de cada pet aumenta progressivamente com base no seu Level e nos seus Resets acumulados!',
            'types' => [
                ['name' => 'Melee Iniciante', 'tier' => 2, 'summon_item' => 'Larva Summon (ID: 11211)', 'hp_base' => '200.000', 'avg_damage' => '40.000 a 60.000', 'role' => 'Atacante Corpo-a-Corpo', 'function_desc' => 'Auxilia no dano físico constante de alvo único e ajuda na velocidade de limpeza de hunts iniciais.'],
                ['name' => 'Tank Iniciante', 'tier' => 2, 'summon_item' => 'Dark Monk Summon (ID: 11214)', 'hp_base' => '300.000', 'avg_damage' => '25.000 a 35.000', 'role' => 'Defensor / Provocador Inicial', 'function_desc' => 'Ajuda a agrar e absorver o dano físico de criaturas mais fracas para proteger magos e arqueiros.'],
                ['name' => 'Ranged Iniciante', 'tier' => 2, 'summon_item' => 'Ranged Summon (ID: 12432)', 'hp_base' => '200.000', 'avg_damage' => '35.000 a 50.000', 'role' => 'Atirador de Retaguarda', 'function_desc' => 'Ataca à distância com projéteis mágicos evitando combate corpo-a-corpo direto.'],
                ['name' => 'Blocker', 'tier' => 3, 'summon_item' => 'Blocker Summon (ID: 11361)', 'hp_base' => '1.500.000', 'avg_damage' => '80.000 a 120.000', 'role' => 'Super Tanque de Boss', 'function_desc' => 'Tanque robusto ideal para bosses médios. Possui inteligência artificial para desafiar criaturas (Challenge).'],
                ['name' => 'Matador', 'tier' => 3, 'summon_item' => 'Killer Summon (ID: 10558)', 'hp_base' => '800.000', 'avg_damage' => '150.000 a 220.000', 'role' => 'Atacante Burst de Alvo Único', 'function_desc' => 'Causa altíssimos picos de dano físico e sangramento persistente na criatura atacada.'],
                ['name' => 'Cat', 'tier' => 3, 'summon_item' => 'Cat Summon (ID: 11192)', 'hp_base' => '800.000', 'avg_damage' => '90.000 a 140.000', 'role' => 'Suporte / Controle de Grupo', 'function_desc' => 'Dificulta a fuga e mobilidade de monstros ágeis aplicando lentidão (Paralyze) constante.'],
                ['name' => 'Parrot', 'tier' => 3, 'summon_item' => 'Terror Bird Summon (ID: 12431)', 'hp_base' => '800.000', 'avg_damage' => '100.000 a 160.000 (Área)', 'role' => 'Atacante de Área (Wave/Spells)', 'function_desc' => 'Ataca alvos múltiplos espalhando dano de vento e furacões ao redor das criaturas.'],
                ['name' => 'Holy Guardian', 'tier' => 3, 'summon_item' => 'Holy Summon (ID: 10420)', 'hp_base' => '700.000', 'avg_damage' => '40.000 a 70.000', 'role' => 'Suporte / Curador Sagrado', 'function_desc' => 'Cura periodicamente grandes fatias da vida do dono utilizando feitiços de luz divina.'],
                ['name' => 'Frost Guardian', 'tier' => 4, 'summon_item' => 'Cryo Summon (ID: 11493)', 'hp_base' => '5.000.000', 'avg_damage' => '300.000 a 450.000', 'role' => 'Super Tanque Criogênico', 'function_desc' => 'Altíssima durabilidade, imunidades e resistências gerais elevadas para hunts end-game extremas.'],
                ['name' => 'Swamp Beast', 'tier' => 4, 'summon_item' => 'Swamp Summon (ID: 6566)', 'hp_base' => '5.000.000', 'avg_damage' => '350.000 a 500.000 (Área)', 'role' => 'Colosso Ofensivo / Veneno', 'function_desc' => 'Descarrega nuvens de veneno em área que corroem a vida de hordas inteiras de monstros.'],
                ['name' => 'Shadow Acolyte', 'tier' => 4, 'summon_item' => 'Shadow Summon (ID: 5802)', 'hp_base' => '2.500.000', 'avg_damage' => '500.000 a 750.000', 'role' => 'Mago Negro de Dano Extremo', 'function_desc' => 'Lança mísseis de morte e drena energia vital dos oponentes para infligir danos absurdos.'],
                ['name' => 'Divine Sentinel', 'tier' => 4, 'summon_item' => 'Sentinel Summon (ID: 9649)', 'hp_base' => '2.000.000', 'avg_damage' => '200.000 a 350.000', 'role' => 'Anjo Protetor Sagrado', 'function_desc' => 'Concede escudos protetores temporários e buffs passivos de defesa física e elemental para o invocador.'],
                ['name' => 'Carrasco', 'tier' => 4, 'summon_item' => 'Executioner Summon (ID: 10411)', 'hp_base' => '2.500.000', 'avg_damage' => '350.000 a 600.000', 'role' => 'Guerreiro Carrasco / Finalizador', 'function_desc' => 'Amplifica consideravelmente o dano de seus ataques conforme a vida do inimigo diminui (Mecânica de Execução).']
            ]
        ],
        'upgrades' => [
            'name' => 'Upgrades (Tier & Awakening)',
            'description' => 'Eleve suas armas e escudos para o nível lendário através de runas e gemas especiais.',
            'mechanics' => [
                ['name' => 'Armas Despertas (Awakening)', 'details' => 'Libera de 1 a 3 slots de atributos secundários aleatórios (como Life Leech, Mana Leech, Critical Chance e Velocidade de Movimento).'],
                ['name' => 'Tier Upgrades (Até Tier 10)', 'details' => 'Aumenta linearmente o dano e defesa base dos equipamentos utilizando minérios de ferro e gemas brutas obtidas em Quests diárias.']
            ]
        ],
        'foods' => [
            'name' => 'Alimentos Especiais (Dietas)',
            'description' => 'Aumente temporariamente seus atributos consumindo pratos cozinhados por alquimistas.',
            'dishes' => [
                ['name' => 'Bolo Vulcânico (Vulcão)', 'effect' => '5% de chance de conjurar uma grande explosão de fogo (GFB) ao acertar ataques físicos.'],
                ['name' => 'Sopa Marinha', 'effect' => 'Recupera 10% de toda mana máxima instantaneamente (Cooldown de 1 hora).'],
                ['name' => 'Salada Sagrada', 'effect' => 'Garante 15% de resistência extra a ataques de dano de morte (Death Damage) por 30 minutos.']
            ]
        ]
    ];

    $stmt = $pdoWeb->prepare(
        "INSERT INTO web_systems (category,name,description,config) VALUES (:category,:name,:description,:config)
         ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), config=VALUES(config)"
    );
    foreach ($systems as $cat => $sys) {
        $stmt->execute([
            'category' => $cat,
            'name' => $sys['name'],
            'description' => $sys['description'],
            'config' => json_encode(array_diff_key($sys, ['name' => 1, 'description' => 1]))
        ]);
    }
    return 'ok: ' . count($systems) . ' sistemas';
}

// ---------------------------------------------------------------
// ROTEADOR
// ---------------------------------------------------------------
try {
    ensureSchema($pdoWeb);
    $results['schema'] = 'ok';
} catch (PDOException $e) {
    $results['schema'] = 'erro: ' . $e->getMessage();
}

$map = [
    'accounts' => function() use ($pdo, $pdoWeb) { return syncAccounts($pdo, $pdoWeb); },
    'items'    => function() use ($pdoWeb) { return syncItems($pdoWeb); },
    'monsters' => function() use ($pdoWeb) { return syncMonsters($pdoWeb); },
    'players'  => function() use ($pdo, $pdoWeb) { return syncPlayers($pdo, $pdoWeb); },
    'systems'  => function() use ($pdoWeb) { return syncSystems($pdoWeb); },
];

if ($action === 'full') {
    foreach ($map as $key => $fn) {
        try { $results[$key] = $fn(); } catch (Throwable $e) { $results[$key] = 'erro: ' . $e->getMessage(); }
    }
} elseif (isset($map[$action])) {
    try { $results[$action] = $map[$action](); } catch (Throwable $e) { $results[$action] = 'erro: ' . $e->getMessage(); }
} else {
    $results['status'] = 'Ação desconhecida. Use: full, schema, accounts, items, monsters, players, systems';
}

$results['elapsed'] = round(microtime(true) - $start, 2) . 's';
echo json_encode(['success' => true, 'results' => $results]);