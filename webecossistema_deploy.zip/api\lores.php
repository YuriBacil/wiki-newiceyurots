<?php
/**
 * API de Lores (Crônicas) Dinâmicas - IceYuriots OT
 * Permite listar as lores do banco de dados e cadastrar novas se o usuário for Admin.
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

session_start();

function getWebGroup() {
    return isset($_SESSION['web_group']) ? (int)$_SESSION['web_group'] : 1;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list':
        try {
            $stmt = $pdoWeb->query("SELECT id, title, content FROM web_lores ORDER BY id ASC");
            $lores = $stmt->fetchAll();
            
            if (!$lores) {
                // Fallback estático se a tabela estiver vazia
                $lores = [
                    [
                        'id' => 1,
                        'title' => 'Capítulo I: O Despertar de IceYurots',
                        'content' => 'No início das eras, quando o gelo dominava as terras do norte de Tibia, os antigos Elite Knights forjaram alianças com magos elementares para fundar o templo de IceYurots.'
                    ],
                    [
                        'id' => 2,
                        'title' => 'Capítulo II: A Lenda da Golden Falcon',
                        'content' => 'Diz a profecia que apenas o guerreiro que acumular frags suficientes nas arenas PVP será digno de empunhar a lendária Golden Falcon.'
                    ]
                ];
            }
            
            echo json_encode(['success' => true, 'lores' => $lores]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao listar crônicas: ' . $e->getMessage()]);
        }
        break;

    case 'create':
        // Apenas Admin (web_group = 3) pode criar Lores
        if (getWebGroup() < 3) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado. Apenas o Administrador/GOD pode cadastrar Lores.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $title = isset($data['title']) ? htmlspecialchars(strip_tags(trim($data['title'])), ENT_QUOTES, 'UTF-8') : '';
        $content = isset($data['content']) ? htmlspecialchars(strip_tags(trim($data['content'])), ENT_QUOTES, 'UTF-8') : '';

        if (empty($title) || empty($content)) {
            echo json_encode(['success' => false, 'message' => 'Título e conteúdo são obrigatórios.']);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("INSERT INTO web_lores (title, content) VALUES (:title, :content)");
            $stmt->execute(['title' => $title, 'content' => $content]);
            echo json_encode(['success' => true, 'message' => 'Nova crônica adicionada com sucesso!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao salvar a crônica no banco: ' . $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Ação desconhecida.']);
        break;
}
