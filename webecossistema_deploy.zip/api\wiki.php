<?php
/**
 * API da Wiki e Biblioteca - IceYuriots OT (VERSÃO DESACOPLADA)
 * Lê TODOS os dados exclusivamente do banco do site (web), que é alimentado
 * pelo importador api/sync.php. Não acessa arquivos do TFS nem o banco do jogo.
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    // ---------------------------------------------------------------
    case 'monsters':
        $tier = isset($_GET['tier']) ? $_GET['tier'] : 'tier1';
        $search = isset($_GET['search']) ? trim($_GET['search']) : '';

        try {
            $where = "WHERE m.tier = :tier";
            $params = ['tier' => $tier];
            if (!empty($search)) {
                $where .= " AND m.name LIKE :search";
                $params['search'] = '%' . $search . '%';
            }

            $stmt = $pdoWeb->prepare("
                SELECT m.id, m.name, m.tier, m.hp, m.xp, m.speed, m.looktype,
                       m.level_range, m.max_dano, m.mage_hp, m.pally_hp, m.knight_hp
                FROM web_monsters m
                $where
                ORDER BY m.hp ASC
                LIMIT 60
            ");
            $stmt->execute($params);
            $monsters = $stmt->fetchAll();

            if (!$monsters) {
                echo json_encode(['success' => true, 'data' => []]);
                exit;
            }

            $ids = array_column($monsters, 'id');
            $in = implode(',', array_map('intval', $ids));
            $stmtLoot = $pdoWeb->query("SELECT monster_id, itemid, name, chance, countmax FROM web_monster_loot WHERE monster_id IN ($in)");
            $lootByMonster = [];
            foreach ($stmtLoot->fetchAll() as $l) {
                $lootByMonster[$l['monster_id']][] = [
                    'itemid' => (int)$l['itemid'],
                    'name' => $l['name'],
                    'chance' => (float)$l['chance'],
                    'countmax' => (int)$l['countmax']
                ];
            }

            foreach ($monsters as &$m) {
                $m['hp'] = (int)$m['hp'];
                $m['xp'] = (int)$m['xp'];
                $m['speed'] = (int)$m['speed'];
                $m['looktype'] = (int)$m['looktype'];
                $m['loot'] = isset($lootByMonster[$m['id']]) ? $lootByMonster[$m['id']] : [];
            }

            echo json_encode(['success' => true, 'data' => $monsters]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao carregar bestiário.']);
        }
        break;

    // ---------------------------------------------------------------
    case 'items':
        $tier = isset($_GET['tier']) ? $_GET['tier'] : 'tier1';
        $category = isset($_GET['category']) ? $_GET['category'] : 'all';
        $search = isset($_GET['search']) ? trim($_GET['search']) : '';

        try {
            $where = "WHERE i.tier = :tier";
            $params = ['tier' => $tier];
            if ($category !== 'all') {
                $where .= " AND LOWER(i.slot) = :category";
                $params['category'] = $category;
            }
            if (!empty($search)) {
                $where .= " AND i.name LIKE :search";
                $params['search'] = '%' . $search . '%';
            }

            $stmt = $pdoWeb->prepare("
                SELECT i.id, i.name, i.attack, i.defense, i.armor, i.weight, i.slot,
                       i.description, i.id_860, i.id_10, i.attributes_desc
                FROM web_items i
                $where
                ORDER BY i.name ASC
            ");
            $stmt->execute($params);
            $items = $stmt->fetchAll();

            if (!$items) {
                echo json_encode(['success' => true, 'data' => []]);
                exit;
            }

            $ids = array_column($items, 'id');
            $in = implode(',', array_map('intval', $ids));
            // Apenas criaturas já cadastradas no site (web_monsters) são válidas como fonte de drop
            $stmtDrops = $pdoWeb->query("SELECT d.item_id, d.monster, d.chance
                FROM web_item_drops d
                INNER JOIN web_monsters m ON LOWER(TRIM(m.name)) = LOWER(TRIM(d.monster))
                WHERE d.item_id IN ($in)");
            $dropsByItem = [];
            foreach ($stmtDrops->fetchAll() as $d) {
                $dropsByItem[$d['item_id']][] = ['monster' => $d['monster'], 'chance' => $d['chance']];
            }

            foreach ($items as &$it) {
                $it['attack'] = (int)$it['attack'];
                $it['defense'] = (int)$it['defense'];
                $it['armor'] = (int)$it['armor'];
                $it['weight'] = (float)$it['weight'];
                $it['id_860'] = (int)$it['id_860'];
                $it['id_10'] = (int)$it['id_10'];
                $it['drops'] = isset($dropsByItem[$it['id']]) ? $dropsByItem[$it['id']] : [];
            }

            echo json_encode(['success' => true, 'data' => $items]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao carregar catálogo de equipamentos.']);
        }
        break;

    // ---------------------------------------------------------------
    case 'custom_systems':
        try {
            $stmt = $pdoWeb->query("SELECT category, name, description, config FROM web_systems");
            $systems = $stmt->fetchAll();
            $response = ['success' => true];
            foreach ($systems as $sys) {
                $config = json_decode($sys['config'], true);
                $response[$sys['category']] = [
                    'name' => $sys['name'],
                    'description' => $sys['description']
                ] + (is_array($config) ? $config : []);
            }
            echo json_encode($response);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao carregar sistemas custom.']);
        }
        break;

    // ---------------------------------------------------------------
    default:
        echo json_encode(['success' => false, 'message' => 'Ação não suportada.']);
        break;
}