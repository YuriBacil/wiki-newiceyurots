<?php
/**
 * API da Comunidade (Mini-Reddit) para o IceYuriots OT - Ajustada para retornar dados vazios amigáveis
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

session_start();

function getLoggedInAccountId() {
    return isset($_SESSION['account_id']) ? (int)$_SESSION['account_id'] : null;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list':
        try {
            $accountId = getLoggedInAccountId();
            
            // 1. Algoritmo de Auto-Archive de Tópicos Mortos (Reddit-Style Archive)
            $pdoWeb->exec("DELETE FROM web_community_posts WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY) AND id NOT IN (
                SELECT DISTINCT post_id FROM web_community_votes WHERE vote_type = 1
            )");

            // 2. Parâmetros de Filtro e Busca
            $filter = isset($_GET['filter']) ? $_GET['filter'] : 'em_alta'; // em_alta, mais_votados, recentes
            $search = isset($_GET['search']) ? trim($_GET['search']) : '';

            // 3. Montar Clausula WHERE para busca
            $whereClause = "";
            $params = ['current_account_id' => $accountId];
            if (!empty($search)) {
                $whereClause = "WHERE (p.title LIKE :search_title OR p.content LIKE :search_content)";
                $params['search_title'] = '%' . $search . '%';
                $params['search_content'] = '%' . $search . '%';
            }

            // 4. Algoritmo Reddit Hot Score (Em Alta)
            // O algoritmo oficial do Reddit computa o Hot Score somando o logaritmo da pontuação
            // com o tempo Unix de criação dividido por 45.000 (tempo de decaimento de 12.5 horas).
            // Em SQL puro para MariaDB/MySQL, isso é modelado calculando:
            // LOG10(GREATEST(1, ABS(upvotes - downvotes))) + (UNIX_TIMESTAMP(created_at) / 45000)
            $orderBy = "(COALESCE(SUM(CASE WHEN v.vote_type = 1 THEN 1 ELSE 0 END), 0) - COALESCE(SUM(CASE WHEN v.vote_type = -1 THEN 1 ELSE 0 END), 0)) DESC, p.created_at DESC"; // Fallback
            if ($filter === 'recentes') {
                $orderBy = "p.created_at DESC";
            } elseif ($filter === 'mais_votados') {
                $orderBy = "(COALESCE(SUM(CASE WHEN v.vote_type = 1 THEN 1 ELSE 0 END), 0) - COALESCE(SUM(CASE WHEN v.vote_type = -1 THEN 1 ELSE 0 END), 0)) DESC, p.created_at DESC";
            } elseif ($filter === 'em_alta') {
                // Algoritmo matemático profissional de Relevância (Decaimento Temporal)
                // Usando a fórmula explícita no lugar do alias 'score' para total compatibilidade com MariaDB
                $orderBy = "LOG10(GREATEST(1, ABS(COALESCE(SUM(CASE WHEN v.vote_type = 1 THEN 1 ELSE 0 END), 0) - COALESCE(SUM(CASE WHEN v.vote_type = -1 THEN 1 ELSE 0 END), 0)))) + (UNIX_TIMESTAMP(p.created_at) / 45000) DESC";
            }

            $sql = "
                SELECT 
                    p.id, 
                    p.account_id,
                    p.title, 
                    p.content, 
                    p.created_at, 
                    COALESCE(SUM(CASE WHEN v.vote_type = 1 THEN 1 ELSE 0 END), 0) AS upvotes,
                    COALESCE(SUM(CASE WHEN v.vote_type = -1 THEN 1 ELSE 0 END), 0) AS downvotes,
                    (COALESCE(SUM(CASE WHEN v.vote_type = 1 THEN 1 ELSE 0 END), 0) - COALESCE(SUM(CASE WHEN v.vote_type = -1 THEN 1 ELSE 0 END), 0)) AS score,
                    (SELECT vote_type FROM web_community_votes WHERE post_id = p.id AND account_id = :current_account_id LIMIT 1) AS user_vote,
                    (SELECT COUNT(*) FROM web_community_comments WHERE post_id = p.id) AS comments_count
                FROM web_community_posts p
                LEFT JOIN web_community_votes v ON p.id = v.post_id
                $whereClause
                GROUP BY p.id
                ORDER BY $orderBy
            ";
            
            $stmt = $pdoWeb->prepare($sql);
            $stmt->execute($params);
            $posts = $stmt->fetchAll();

            if (!$posts) {
                $posts = [];
            }

            // Agora buscamos as informações das contas correspondentes no banco do site (web_accounts)
            if (count($posts) > 0) {
                $accountIds = array_unique(array_column($posts, 'account_id'));
                $inQuery = implode(',', array_map('intval', $accountIds));
                
                $stmtAcc = $pdoWeb->query("SELECT id, name, web_group FROM web_accounts WHERE id IN ($inQuery)");
                $accountsMap = [];
                while ($acc = $stmtAcc->fetch()) {
                    $accountsMap[$acc['id']] = $acc;
                }

                foreach ($posts as &$post) {
                    $authorId = $post['account_id'];
                    $post['author_name'] = isset($accountsMap[$authorId]) ? $accountsMap[$authorId]['name'] : 'Player Desconhecido';
                    $post['author_group'] = isset($accountsMap[$authorId]) ? (int)$accountsMap[$authorId]['web_group'] : 1;
                }
            }

            $currentUserGroup = isset($_SESSION['web_group']) ? (int)$_SESSION['web_group'] : 1;
            echo json_encode(['success' => true, 'posts' => $posts, 'user_group' => $currentUserGroup]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'posts' => [], 'user_group' => 1, 'debug_message' => $e->getMessage()]);
        }
        break;

    case 'delete':
        $userGroup = isset($_SESSION['web_group']) ? (int)$_SESSION['web_group'] : 1;
        
        // Apenas moderador (2) ou GOD (3) podem deletar posts
        if ($userGroup < 2) {
            echo json_encode(['success' => false, 'message' => 'Você não tem permissão para deletar este post.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $postId = isset($data['post_id']) ? (int)$data['post_id'] : 0;

        if ($postId <= 0) {
            echo json_encode(['success' => false, 'message' => 'ID do post inválido.']);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("DELETE FROM web_community_posts WHERE id = ?");
            $stmt->execute([$postId]);
            echo json_encode(['success' => true, 'message' => 'Post removido com sucesso pela moderação!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao deletar post: ' . $e->getMessage()]);
        }
        break;

    case 'create':
        if (!getLoggedInAccountId()) {
            echo json_encode(['success' => false, 'message' => 'Você precisa estar logado para postar.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $title = isset($data['title']) ? htmlspecialchars(strip_tags(trim($data['title'])), ENT_QUOTES, 'UTF-8') : '';
        $content = isset($data['content']) ? htmlspecialchars(strip_tags(trim($data['content'])), ENT_QUOTES, 'UTF-8') : '';

        if (mb_strlen($title) < 3 || mb_strlen($title) > 50) {
            echo json_encode(['success' => false, 'message' => 'O título deve ter entre 3 e 50 caracteres.']);
            exit;
        }

        if (mb_strlen($content) < 5 || mb_strlen($content) > 500) {
            echo json_encode(['success' => false, 'message' => 'O conteúdo deve ter entre 5 e 500 caracteres.']);
            exit;
        }

        // 1. Cooldown anti-spam de 15 segundos entre postagens
        $lastPostTime = isset($_SESSION['last_post_time']) ? (int)$_SESSION['last_post_time'] : 0;
        $now = time();
        if (($now - $lastPostTime) < 15) {
            $secondsRemaining = 15 - ($now - $lastPostTime);
            echo json_encode(['success' => false, 'message' => "Aguarde {$secondsRemaining} segundos antes de criar um novo tópico."]);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("INSERT INTO web_community_posts (account_id, title, content, created_at) VALUES (:account_id, :title, :content, NOW())");
            $stmt->execute([
                'account_id' => getLoggedInAccountId(),
                'title' => $title,
                'content' => $content
            ]);
            $_SESSION['last_post_time'] = time();
            echo json_encode(['success' => true, 'message' => 'Post criado com sucesso!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao salvar o post no banco: ' . $e->getMessage()]);
        }
        break;

    case 'vote':
        $accountId = getLoggedInAccountId();
        if (!$accountId) {
            echo json_encode(['success' => false, 'message' => 'Você precisa estar logado para votar.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $postId = isset($data['post_id']) ? (int)$data['post_id'] : 0;
        $voteType = isset($data['vote_type']) ? (int)$data['vote_type'] : 0;

        if ($postId <= 0 || !in_array($voteType, [1, -1, 0])) {
            echo json_encode(['success' => false, 'message' => 'Parâmetros de voto inválidos.']);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("SELECT id FROM web_community_posts WHERE id = ?");
            $stmt->execute([$postId]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Post não encontrado.']);
                exit;
            }

            if ($voteType === 0) {
                $stmt = $pdoWeb->prepare("DELETE FROM web_community_votes WHERE post_id = :post_id AND account_id = :account_id");
                $stmt->execute(['post_id' => $postId, 'account_id' => $accountId]);
            } else {
                // Como :vote_type é mencionado duas vezes na query, quando a emulação de prepared statements do PDO está desativada,
                // precisamos passar os parâmetros posicionais de forma exata ou declarar as duas menções separadamente.
                $stmt = $pdoWeb->prepare("
                    INSERT INTO web_community_votes (post_id, account_id, vote_type) 
                    VALUES (:post_id, :account_id, :vote_type)
                    ON DUPLICATE KEY UPDATE vote_type = :vote_type_update
                ");
                $stmt->execute([
                    'post_id' => $postId,
                    'account_id' => $accountId,
                    'vote_type' => $voteType,
                    'vote_type_update' => $voteType
                ]);
            }

            $stmt = $pdoWeb->prepare("
                SELECT 
                    COALESCE(SUM(CASE WHEN vote_type = 1 THEN 1 ELSE 0 END), 0) - 
                    COALESCE(SUM(CASE WHEN vote_type = -1 THEN 1 ELSE 0 END), 0) AS new_score
                FROM web_community_votes
                WHERE post_id = ?
            ");
            $stmt->execute([$postId]);
            $scoreData = $stmt->fetch();
            $newScore = $scoreData ? (int)$scoreData['new_score'] : 0;

            echo json_encode(['success' => true, 'new_score' => $newScore]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao processar voto: ' . $e->getMessage()]);
        }
        break;

    case 'list_comments':
        $postId = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;
        if ($postId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Post inválido.']);
            exit;
        }

        try {
            $accountId = getLoggedInAccountId();
            // Puxamos todos os comentários da postagem ordenando pela criação
            $stmt = $pdoWeb->prepare("
                SELECT 
                    c.id, 
                    c.parent_id,
                    c.account_id,
                    c.content, 
                    c.created_at,
                    COALESCE(SUM(CASE WHEN cv.vote_type = 1 THEN 1 ELSE 0 END), 0) AS upvotes,
                    COALESCE(SUM(CASE WHEN cv.vote_type = -1 THEN 1 ELSE 0 END), 0) AS downvotes,
                    (COALESCE(SUM(CASE WHEN cv.vote_type = 1 THEN 1 ELSE 0 END), 0) - COALESCE(SUM(CASE WHEN cv.vote_type = -1 THEN 1 ELSE 0 END), 0)) AS score,
                    (SELECT vote_type FROM web_community_comment_votes WHERE comment_id = c.id AND account_id = :current_account_id LIMIT 1) AS user_vote
                FROM web_community_comments c
                LEFT JOIN web_community_comment_votes cv ON c.id = cv.comment_id
                WHERE c.post_id = :post_id
                GROUP BY c.id
                ORDER BY c.created_at ASC
            ");
            $stmt->execute(['post_id' => $postId, 'current_account_id' => $accountId]);
            $comments = $stmt->fetchAll();

            if (!$comments) {
                $comments = [];
            }

            // Cruzando com as contas do jogo para trazer apelido e web_group
            if (count($comments) > 0) {
                $accountIds = array_unique(array_column($comments, 'account_id'));
                $inQuery = implode(',', array_map('intval', $accountIds));
                
                $stmtAcc = $pdoWeb->query("SELECT id, name, web_group FROM web_accounts WHERE id IN ($inQuery)");
                $accountsMap = [];
                while ($acc = $stmtAcc->fetch()) {
                    $accountsMap[$acc['id']] = $acc;
                }

                foreach ($comments as &$comm) {
                    $authId = $comm['account_id'];
                    $comm['author_name'] = isset($accountsMap[$authId]) ? $accountsMap[$authId]['name'] : 'Jogador Desconhecido';
                    $comm['author_group'] = isset($accountsMap[$authId]) ? (int)$accountsMap[$authId]['web_group'] : 1;
                }
            }

            echo json_encode(['success' => true, 'comments' => $comments]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao listar comentários: ' . $e->getMessage()]);
        }
        break;

    case 'add_comment':
        $accountId = getLoggedInAccountId();
        if (!$accountId) {
            echo json_encode(['success' => false, 'message' => 'Você precisa estar logado para comentar.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $postId = isset($data['post_id']) ? (int)$data['post_id'] : 0;
        $parentId = isset($data['parent_id']) && $data['parent_id'] > 0 ? (int)$data['parent_id'] : null;
        $content = isset($data['content']) ? htmlspecialchars(strip_tags(trim($data['content'])), ENT_QUOTES, 'UTF-8') : '';

        if ($postId <= 0 || empty($content)) {
            echo json_encode(['success' => false, 'message' => 'Conteúdo de comentário inválido.']);
            exit;
        }

        // 2. Cooldown anti-spam de 15 segundos entre comentários
        $lastCommentTime = isset($_SESSION['last_comment_time']) ? (int)$_SESSION['last_comment_time'] : 0;
        $now = time();
        if (($now - $lastCommentTime) < 15) {
            $secondsRemaining = 15 - ($now - $lastCommentTime);
            echo json_encode(['success' => false, 'message' => "Aguarde {$secondsRemaining} segundos antes de comentar novamente."]);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("
                INSERT INTO web_community_comments (post_id, parent_id, account_id, content) 
                VALUES (:post_id, :parent_id, :account_id, :content)
            ");
            $stmt->execute([
                'post_id' => $postId,
                'parent_id' => $parentId,
                'account_id' => $accountId,
                'content' => $content
            ]);

            $_SESSION['last_comment_time'] = time();

            echo json_encode(['success' => true, 'message' => 'Comentário publicado!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao publicar comentário: ' . $e->getMessage()]);
        }
        break;

    case 'vote_comment':
        $accountId = getLoggedInAccountId();
        if (!$accountId) {
            echo json_encode(['success' => false, 'message' => 'Você precisa estar logado para votar.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método inválido.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $commentId = isset($data['comment_id']) ? (int)$data['comment_id'] : 0;
        $voteType = isset($data['vote_type']) ? (int)$data['vote_type'] : 0;

        if ($commentId <= 0 || !in_array($voteType, [1, -1, 0])) {
            echo json_encode(['success' => false, 'message' => 'Parâmetros de voto inválidos.']);
            exit;
        }

        try {
            if ($voteType === 0) {
                $stmt = $pdoWeb->prepare("DELETE FROM web_community_comment_votes WHERE comment_id = :comment_id AND account_id = :account_id");
                $stmt->execute(['comment_id' => $commentId, 'account_id' => $accountId]);
            } else {
                $stmt = $pdoWeb->prepare("
                    INSERT INTO web_community_comment_votes (comment_id, account_id, vote_type) 
                    VALUES (:comment_id, :account_id, :vote_type)
                    ON DUPLICATE KEY UPDATE vote_type = :vote_type_update
                ");
                $stmt->execute([
                    'comment_id' => $commentId,
                    'account_id' => $accountId,
                    'vote_type' => $voteType,
                    'vote_type_update' => $voteType
                ]);
            }

            $stmt = $pdoWeb->prepare("
                SELECT 
                    COALESCE(SUM(CASE WHEN vote_type = 1 THEN 1 ELSE 0 END), 0) - 
                    COALESCE(SUM(CASE WHEN vote_type = -1 THEN 1 ELSE 0 END), 0) AS new_score
                FROM web_community_comment_votes
                WHERE comment_id = ?
            ");
            $stmt->execute([$commentId]);
            $scoreData = $stmt->fetch();
            $newScore = $scoreData ? (int)$scoreData['new_score'] : 0;

            echo json_encode(['success' => true, 'new_score' => $newScore]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao registrar voto do comentário: ' . $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Ação desconhecida.']);
        break;
}
