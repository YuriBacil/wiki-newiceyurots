<?php
/**
 * Configurações de Ambiente - IceYuriots OT
 * Detecta dinamicamente se o servidor está rodando localmente (desenvolvimento) ou na VPS (produção).
 */

// 1. Detectar ambiente
// - Via navegador (Apache/XAMPP) usando REMOTE_ADDR/SERVER_NAME
// - Via CLI/cron (importador) sempre tratado como ambiente local
$isCli = (php_sapi_name() === 'cli');
$isLocal = $isCli || in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1']) || ($_SERVER['SERVER_NAME'] ?? '') === 'localhost';

if ($isLocal) {
    // Ambiente Local (Seu computador com XAMPP)
    define('TFS_PATH', 'Y:/Desktop/Pessoal/Projetos/Projeto de Jogo/OT Tibia/Compartilhado/IceYuriots OT - TFS 1.5');
    define('CONSOLE_LOG_PATH', 'Y:/Desktop/Pessoal/Projetos/Projeto de Jogo/OT Tibia/Compartilhado/IceYuriots OT - TFS 1.5/console.log');
} else {
    // Ambiente de Produção (Sua VPS Linux ou Windows Oficial)
    // Altere o caminho abaixo para a pasta absoluta onde o TFS está na VPS. Exemplo: 'C:/otserver' ou '/home/otserver'
    define('TFS_PATH', 'C:/YuriotsServer/TFS_1.5');
    define('CONSOLE_LOG_PATH', 'C:/YuriotsServer/TFS_1.5/console.log');
}
