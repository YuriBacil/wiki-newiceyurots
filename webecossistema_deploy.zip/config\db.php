<?php
/**
 * Configuração de banco de dados via PDO - IceYuriots OT
 *
 * ARQUITETURA DESACOPLADA:
 * - $pdoWeb (PRIMÁRIO): Banco de dados EXCLUSIVO do site/painel web.
 *   Todas as APIs do site leem e escrevem SOMENTE aqui.
 *   Contém snapshots dos dados do jogo importados por api/sync.php.
 *
 * - $pdo (LEITURA PARA IMPORTAÇÃO APENAS): Banco de dados do jogo (TFS).
 *   Usado SOMENTE pelo importador api/sync.php para copiar dados do servidor.
 *   Nenhuma API do site deve consultar este banco em runtime.
 */

// 0. Sobrescrita de credenciais para produção (host remoto).
//    Crie um arquivo config/db.override.php (ou use variáveis de ambiente)
//    para definir as credenciais do host remoto sem alterar este arquivo.
if (file_exists(__DIR__ . '/db.override.php')) {
    require __DIR__ . '/db.override.php';
}

// 1. Banco de dados do Site (Exclusivo - fonte primária de tudo)
!defined('DB_WEB_HOST')    && define('DB_WEB_HOST', getenv('DB_WEB_HOST') ?: '127.0.0.1');
!defined('DB_WEB_PORT')    && define('DB_WEB_PORT', getenv('DB_WEB_PORT') ?: '3306');
!defined('DB_WEB_NAME')    && define('DB_WEB_NAME', getenv('DB_WEB_NAME') ?: 'theforgottenserver_web');
!defined('DB_WEB_USER')    && define('DB_WEB_USER', getenv('DB_WEB_USER') ?: 'root');
!defined('DB_WEB_PASS')    && define('DB_WEB_PASS', getenv('DB_WEB_PASS') ?: '');
!defined('DB_WEB_CHARSET') && define('DB_WEB_CHARSET', 'utf8mb4');

// 2. Banco de dados do Jogo (Somente leitura pelo importador)
!defined('DB_GAME_HOST')    && define('DB_GAME_HOST', getenv('DB_GAME_HOST') ?: '127.0.0.1');
!defined('DB_GAME_PORT')    && define('DB_GAME_PORT', getenv('DB_GAME_PORT') ?: '3306');
!defined('DB_GAME_NAME')    && define('DB_GAME_NAME', getenv('DB_GAME_NAME') ?: 'theforgottenserver');
!defined('DB_GAME_USER')    && define('DB_GAME_USER', getenv('DB_GAME_USER') ?: 'root');
!defined('DB_GAME_PASS')    && define('DB_GAME_PASS', getenv('DB_GAME_PASS') ?: '');
!defined('DB_GAME_CHARSET') && define('DB_GAME_CHARSET', 'utf8mb4');

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// Conexão principal do site (obrigatória)
try {
    $dsnWeb = "mysql:host=" . DB_WEB_HOST . ";port=" . DB_WEB_PORT . ";dbname=" . DB_WEB_NAME . ";charset=" . DB_WEB_CHARSET;
    $pdoWeb = new PDO($dsnWeb, DB_WEB_USER, DB_WEB_PASS, $options);
} catch (PDOException $e) {
    die("Erro de infraestrutura: Não foi possível estabelecer conexão com a base de dados do site.");
}

// Conexão com o banco do jogo (somente importador). Fica disponível como $pdo
// mas não deve ser usada pelas APIs em runtime.
$pdo = null;
try {
    $dsnGame = "mysql:host=" . DB_GAME_HOST . ";port=" . DB_GAME_PORT . ";dbname=" . DB_GAME_NAME . ";charset=" . DB_GAME_CHARSET;
    $pdo = new PDO($dsnGame, DB_GAME_USER, DB_GAME_PASS, $options);
} catch (PDOException $e) {
    $pdo = null;
}