<?php
/**
 * API de Estatísticas e Inspect - IceYuriots OT (VERSÃO DESACOPLADA)
 * Lê TODOS os dados exclusivamente do banco do site (web_players, web_player_deaths),
 * que é alimentado pelo importador api/sync.php. Não acessa o banco do jogo.
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

$VOCATIONS = [
    0 => 'None',
    1 => 'Sorcerer', 2 => 'Druid', 3 => 'Paladin', 4 => 'Knight',
    5 => 'Master Sorcerer', 6 => 'Elder Druid', 7 => 'Royal Paladin', 8 => 'Elite Knight'
];

function getCachedRanking($pdoWeb, $type, $cacheTimeSeconds = 300) {
    $now = time();
    $cacheKey = 'ranking_' . $type;
    try {
        $stmt = $pdoWeb->prepare("SELECT cache_value, updated_at FROM web_cache_stats WHERE cache_key = ?");
        $stmt->execute([$cacheKey]);
        $cache = $stmt->fetch();
        if ($cache && ($now - (int)$cache['updated_at']) < $cacheTimeSeconds) {
            return json_decode($cache['cache_value'], true);
        }
        $data = generateRankingData($pdoWeb, $type);
        $stmt = $pdoWeb->prepare(
            "INSERT INTO web_cache_stats (cache_key, cache_value, updated_at) VALUES (:key, :value, :updated)
             ON DUPLICATE KEY UPDATE cache_value = :value, updated_at = :updated"
        );
        $stmt->execute(['key' => $cacheKey, 'value' => json_encode($data), 'updated' => $now]);
        return $data;
    } catch (PDOException $e) {
        return generateRankingData($pdoWeb, $type);
    }
}

function generateRankingData($pdoWeb, $type) {
    global $VOCATIONS;
    try {
        $allowedSkills = [
            'sword' => 'skill_sword', 'axe' => 'skill_axe', 'club' => 'skill_club',
            'dist' => 'skill_dist', 'shielding' => 'skill_shielding'
        ];

        $scoreCol = 'p.level';
        if ($type === 'level') $scoreCol = 'p.level';
        elseif ($type === 'resets') $scoreCol = 'p.resets';
        elseif ($type === 'balance') $scoreCol = 'p.balance';
        elseif ($type === 'maglevel') $scoreCol = 'p.maglevel';
        elseif ($type === 'xptoday') $scoreCol = 'p.experience';
        elseif (isset($allowedSkills[$type])) $scoreCol = 'p.' . $allowedSkills[$type];

        $orderBy = "$scoreCol DESC, p.level DESC";
        if ($type === 'resets') $orderBy = "p.resets DESC, p.level DESC";
        elseif ($type === 'level') $orderBy = "p.level DESC, p.experience DESC";

        if ($type === 'frags') {
            $sql = "
                SELECT p.id, p.name, p.level, p.vocation, p.resets,
                    (SELECT COUNT(*) FROM web_player_deaths d WHERE d.killed_by = p.name AND d.is_player = 1) AS score,
                    p.online
                FROM web_players p
                WHERE p.group_id < 3
                ORDER BY score DESC, p.resets DESC, p.level DESC
                LIMIT 10
            ";
        } else {
            $sql = "
                SELECT p.id, p.name, p.level, p.vocation, p.resets, p.online, $scoreCol AS score
                FROM web_players p
                WHERE p.group_id < 3
                ORDER BY $orderBy
                LIMIT 10
            ";
        }

        $stmt = $pdoWeb->query($sql);
        $players = $stmt->fetchAll();
        if (!$players) return [];

        foreach ($players as &$player) {
            $vocId = (int)$player['vocation'];
            $player['vocation_name'] = isset($VOCATIONS[$vocId]) ? $VOCATIONS[$vocId] : 'Unknown';
            $player['online'] = (bool)$player['online'];

            if ($type === 'xptoday' || $type === 'balance') {
                $val = (float)$player['score'];
                if ($val >= 1000000) $player['score_formatted'] = round($val / 1000000, 1) . 'kk';
                elseif ($val >= 1000) $player['score_formatted'] = round($val / 1000, 1) . 'k';
                else $player['score_formatted'] = $val;
            } elseif ($type === 'resets') {
                $player['score_formatted'] = $player['score'] . ' resets';
            } else {
                $player['score_formatted'] = $player['score'];
            }
        }

        return $players;
    } catch (PDOException $e) {
        return [];
    }
}

switch ($action) {
    // ---------------------------------------------------------------
    case 'ranking':
        $type = isset($_GET['type']) ? $_GET['type'] : 'level';
        if (in_array($type, ['xptoday', 'frags'])) {
            $ranking = getCachedRanking($pdoWeb, $type, 300);
        } else {
            $ranking = generateRankingData($pdoWeb, $type);
        }
        echo json_encode(['success' => true, 'data' => $ranking]);
        break;

    // ---------------------------------------------------------------
    case 'inspect':
        $playerName = isset($_GET['name']) ? trim($_GET['name']) : '';
        if (empty($playerName)) {
            echo json_encode(['success' => false, 'message' => 'Jogador não especificado.']);
            exit;
        }

        try {
            $stmt = $pdoWeb->prepare("
                SELECT * FROM web_players WHERE name = ?
            ");
            $stmt->execute([$playerName]);
            $player = $stmt->fetch();

            if (!$player) {
                echo json_encode(['success' => false, 'message' => 'Jogador não encontrado.']);
                exit;
            }

            $pid = (int)$player['id'];

            // Equipamentos (slots 1 a 10)
            $stmtItems = $pdoWeb->prepare("SELECT pid, itemtype, count FROM web_player_items WHERE player_id = ? AND pid BETWEEN 1 AND 10");
            $stmtItems->execute([$pid]);
            $rawItems = $stmtItems->fetchAll();

            $equipment = array_fill_keys(range(1, 10), null);
            foreach ($rawItems as $item) {
                $equipment[(int)$item['pid']] = [
                    'itemid' => (int)$item['itemtype'],
                    'count' => (int)$item['count'],
                    'name' => 'Item ID: ' . $item['itemtype']
                ];
            }

            // Mortes recentes (máximo 5)
            $stmtDeaths = $pdoWeb->prepare("
                SELECT level, time, killed_by, is_player FROM web_player_deaths
                WHERE player_id = ? ORDER BY time DESC LIMIT 5
            ");
            $stmtDeaths->execute([$pid]);
            $deaths = $stmtDeaths->fetchAll();
            if (!$deaths) $deaths = [];

            echo json_encode([
                'success' => true,
                'player' => [
                    'name' => $player['name'],
                    'level' => (int)$player['level'],
                    'vocation' => (int)$player['vocation'],
                    'sex' => (int)$player['sex'],
                    'online' => (bool)$player['online'],
                    'healthmax' => (int)$player['healthmax'],
                    'manamax' => (int)$player['manamax'],
                    'maglevel' => (int)$player['maglevel'],
                    'lastlogin' => (int)$player['lastlogin'] > 0 ? date('d/m/Y H:i', (int)$player['lastlogin']) : 'Nunca logou',
                    'account_created' => (int)$player['account_created'] > 0 ? date('d/m/Y', (int)$player['account_created']) : 'Desconhecida',
                    'skills' => [
                        'maglevel' => (int)$player['maglevel'],
                        'fist' => (int)$player['skill_fist'],
                        'club' => (int)$player['skill_club'],
                        'sword' => (int)$player['skill_sword'],
                        'axe' => (int)$player['skill_axe'],
                        'dist' => (int)$player['skill_dist'],
                        'shielding' => (int)$player['skill_shielding'],
                        'resets' => (int)$player['resets']
                    ],
                    'guild' => $player['guild_name'] ? [
                        'name' => $player['guild_name'],
                        'rank' => $player['guild_rank']
                    ] : null
                ],
                'equipment' => $equipment,
                'deaths' => $deaths
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao inspecionar jogador.']);
        }
        break;

    // ---------------------------------------------------------------
    case 'world_stats':
        try {
            // Vocações
            $stmtVoc = $pdoWeb->query("SELECT vocation, COUNT(*) AS count FROM web_players WHERE group_id < 3 GROUP BY vocation");
            $formattedVocs = [];
            foreach ($stmtVoc->fetchAll() as $vs) {
                $formattedVocs[] = [
                    'name' => isset($VOCATIONS[(int)$vs['vocation']]) ? $VOCATIONS[(int)$vs['vocation']] : 'Outros',
                    'count' => (int)$vs['count']
                ];
            }

            // Monstros assassinos (PvE)
            $stmtMonsters = $pdoWeb->query("
                SELECT killed_by AS monster_name, COUNT(*) AS kills_count
                FROM web_player_deaths WHERE is_player = 0 AND killed_by <> ''
                GROUP BY killed_by ORDER BY kills_count DESC LIMIT 3
            ");
            $killerMonsters = $stmtMonsters->fetchAll();
            if (!$killerMonsters) $killerMonsters = [];

            // Top PvP Killers
            $stmtKillers = $pdoWeb->query("
                SELECT killed_by AS player_name, COUNT(*) AS kills_count
                FROM web_player_deaths WHERE is_player = 1 AND killed_by <> ''
                GROUP BY killed_by ORDER BY kills_count DESC LIMIT 3
            ");
            $topPvP = $stmtKillers->fetchAll();
            if (!$topPvP) $topPvP = [];

            // Métricas gerais
            $stmtMetrics = $pdoWeb->query("SELECT COUNT(*) AS total_players, AVG(level) AS avg_level FROM web_players WHERE group_id < 3");
            $metricsData = $stmtMetrics->fetch();
            $stmtResets = $pdoWeb->query("SELECT COALESCE(SUM(resets),0) AS sum_resets FROM web_players WHERE group_id < 3");
            $resetsData = $stmtResets->fetch();

            echo json_encode([
                'success' => true,
                'vocations' => $formattedVocs,
                'monsters' => $killerMonsters,
                'pvp' => $topPvP,
                'metrics' => [
                    'total_players' => (int)$metricsData['total_players'],
                    'avg_level' => round((float)$metricsData['avg_level'], 1),
                    'total_resets' => (int)$resetsData['sum_resets']
                ]
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Erro ao compilar dados do mundo.']);
        }
        break;

    // ---------------------------------------------------------------
    default:
        echo json_encode(['success' => false, 'message' => 'Ação desconhecida.']);
        break;
}