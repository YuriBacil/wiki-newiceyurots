<?php
/**
 * API de Cadastro - IceYuriots OT
 * Permite que um usuário crie sua própria conta (login + senha) no painel.
 *
 * MODO PROVISÓRIO: as contas criadas aqui são autônomas do site e ainda não
 * possuem integração com o banco do jogo. A senha é armazenada com hash forte
 * (bcrypt) e nunca em texto puro.
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método de requisição inválido.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$login = isset($data['login']) ? trim($data['login']) : '';
$password = isset($data['password']) ? $data['password'] : '';

// ---- Validações básicas ----
if (mb_strlen($login) < 4 || mb_strlen($login) > 32) {
    echo json_encode(['success' => false, 'message' => 'O login deve ter entre 4 e 32 caracteres.']);
    exit;
}

if (!preg_match('/^[a-zA-Z0-9_.-]+$/', $login)) {
    echo json_encode(['success' => false, 'message' => 'O login só pode conter letras, números, ponto, traço e sublinhado.']);
    exit;
}

if (mb_strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'A senha deve ter pelo menos 6 caracteres.']);
    exit;
}

if (mb_strtolower($password) === mb_strtolower($login)) {
    echo json_encode(['success' => false, 'message' => 'A senha não pode ser igual ao login.']);
    exit;
}

try {
    // Verifica se o login já está em uso
    $check = $pdoWeb->prepare("SELECT id FROM web_accounts WHERE name = ?");
    $check->execute([$login]);
    if ($check->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Este login já está em uso. Escolha outro.']);
        exit;
    }

    // Cria a conta com hash forte (bcrypt)
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdoWeb->prepare("INSERT INTO web_accounts (name, password, web_group, created) VALUES (:name, :password, 1, :created)");
    $stmt->execute([
        'name' => $login,
        'password' => $hash,
        'created' => time()
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Conta criada com sucesso! Lembre-se: o acesso ainda está em MODO PROVISÓRIO. Sua senha está protegida (hash) e pode ser salva no navegador para facilitar o login.'
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao criar a conta. Tente novamente.']);
}